"""
Supplementary Table S5 - sensitivity analyses.

Every row of Table S5 in the manuscript is reproduced here, in the order in
which the rows appear in the table.  Unless a row says "per 1-SD", the estimate
is the hazard ratio of APAR quartile 4 versus quartile 1 from Model 3, with the
quartile boundaries recomputed inside the sensitivity subset (so the contrast is
always the highest versus the lowest quarter of the population actually analysed).

Rows
----
primary   primary analysis (Model 3, Q4 vs Q1)
cc        complete-case analysis - this is the cohort reported as the
          unnumbered first row of Supplementary Table S5, "Primary analysis
          (complete cases, Model 3)"                       (needs --cc-stay)
1   APAR above mean + 3 SD excluded
2   APAR winsorized at the 1st/99th percentile
3   log2(APAR), HR per doubling
4a  ALP alone, per 1 SD
4b  albumin alone, per 1 SD
5   excluding patients given albumin before the index measurement
                                                           (needs --albumin)
6   excluding biliary obstruction / cholangitis
7   sepsis redefined by a baseline-corrected SOFA increase >= 2 (needs --dsofa)
    7b is the strict reading of the same criterion (only patients who
    demonstrably met it) and 7c the formal interaction test quoted in the
    same Table S5 footnote.
8   E-value for the Q4 vs Q1 hazard ratio and its lower confidence limit
9   excluding admissions from 2020 onwards                  (needs --anchor)
10  further adjustment for the white-cell count (Model 4; lactate is not
    entered into any model because it is missing in 18.5% of the cohort)
11  cohort including deaths within 24 h of ICU admission
                                                    (needs --cohort-incl24h)
    Reported per 1 unit (1 IU/L per g/L) rather than as a quartile contrast or
    per SD, for two reasons: (i) every additionally retained patient dies inside
    the first 24 h of follow-up, so a quartile contrast would be dominated by
    those immediate events; (ii) the retained cohort is spread more widely than
    the analysis cohort (SD 4.98 vs 4.71), so a per-1-SD contrast differs from
    Table 2 for reasons of scale alone.  The per-1-SD reading of the *same*
    fitted model is carried in the Note column of both rows, so that the value
    quoted in the Table S5 footnote (1.195 and 1.220) is reproducible from the
    supplied code.
12  time origin moved from ICU admission to the index draw, i.e. the moment APAR
    becomes computable (the later of the first ALP and the first albumin draw).
    This is the immortal-time sensitivity analysis: between ICU admission and
    the index draw a patient cannot die and still be counted, so the clock is
    restarted at the draw (needs --extras)
13  the analysis stratified by whether the index draw preceded or followed
    sepsis onset (needs --extras).  APAR measured before onset and APAR measured
    after onset are not the same quantity biologically: the second is drawn from
    a patient who has already declared the disease course.  Model 3 is therefore
    re-fitted inside each timing stratum - 13a draw before onset, 13b draw after
    onset - and the two are compared by a product term (13c).  APAR is scaled by
    the SD of the whole cohort in both strata, so 13a, 13b and the primary
    per-1-SD estimate are on the same scale and directly comparable; re-scaling
    each stratum by its own SD would make the two estimates incomparable.
14  INR approximated as PT / 11.0 s, kept as a sensitivity row because the
    primary analysis uses the laboratory-reported INR.
15  the brain component of ACLF scored from the lowest Glasgow Coma Scale over
    the whole ICU stay instead of the first 24 h.  The primary analysis uses the
    24-h minimum so that all six components share one baseline window; this row
    re-imposes the wider window - the definition the review queried - so that
    the cost of that choice can be read directly.  The two windows disagree in
    256 patients, all of whom reach GCS <= 8 only after the first day; they are
    also the patients observed for longest, which is why the wider window is
    open to reverse causation (a low GCS near death qualifying the patient for
    "brain failure" at baseline).  The column `gcs_whole` carries this value;
    it is produced by the same extraction SQL and is not used anywhere else.

NOTE ON NUMBERING: the labels written by this script - and therefore the
`Sensitivity` column of results/TableS5_sensitivity.csv - follow Supplementary
Table S5 exactly.  Rows were renumbered on 2026-10-19; before that the script
counted every row it produced, so its labels ran 2 ahead of the table
(script 9 was table row 7).  Only labels and comments changed: no model,
no covariate set and no estimate was touched, so every number in the output
is unchanged.

The auxiliary input files are small extracts from MIMIC-IV; the queries that
produce them are in sql/03_sensitivity_cohorts.sql.  Row 11 re-runs the same
extraction with the 24-h mortality exclusion switched off, giving a retained
cohort of N = 1,927 (661 deaths at 30 days, 817 at 90 days), of which
1,891 are complete cases; the resulting file is --cohort-incl24h.
"""
import warnings

warnings.filterwarnings('ignore')

import os

import numpy as np
import pandas as pd
from lifelines import CoxPHFitter

from apar_common import (ADJ, HORIZONS, albumin_to_gl, apar_from, common_args,
                         e_value, load_cohort, meld_na_from, resolve_path,
                         survival_frame)

PENALIZER = 1e-6


def cox_summary(d):
    cph = CoxPHFitter(penalizer=PENALIZER)
    cph.fit(d, duration_col='T', event_col='E', show_progress=False)
    return cph


def q4_vs_q1(data, T, E, cov):
    """HR of quartile 4 vs quartile 1; quartiles are cut inside `data`.

    Returns (HR, lo, hi, P, n_analysed, n_events); `n_analysed` and `n_events`
    describe the patients actually fitted, i.e. the complete-case subset - NOT
    the cohort they were drawn from.  Reporting `n_analysed` next to the event
    count of the parent cohort is what used to make Table S5 inconsistent.
    """
    dd = data.copy()
    dd['apar_q'] = pd.qcut(dd['apar'], 4, labels=['Q1', 'Q2', 'Q3', 'Q4'])
    dums = pd.get_dummies(dd['apar_q'], prefix='q', dtype=float)
    dd = pd.concat([dd, dums], axis=1)
    keep = ['q_Q2', 'q_Q3', 'q_Q4'] + [c for c in cov if c != 'apar']
    frame = survival_frame(dd.rename(columns={T: 'T', E: 'E'}), keep, 'T', 'E')
    cph = cox_summary(frame)
    s = cph.summary.loc['q_Q4']
    return (s['exp(coef)'], s['exp(coef) lower 95%'], s['exp(coef) upper 95%'],
            float(s['p']), len(frame), int(frame['E'].sum()))


def per_sd(data, xcol, T, E, cov):
    """HR per 1 SD of `xcol`, the SD being taken in `data`."""
    return per_sd_at(data, xcol, T, E, cov, data[xcol].std(ddof=1))


def per_sd_at(data, xcol, T, E, cov, sd):
    """HR per `sd` units of `xcol`, the SD being supplied by the caller.

    Used for stratified comparisons: every stratum has to be expressed on the
    scale of the whole cohort, otherwise the stratum estimates are not
    comparable with each other or with the primary per-1-SD estimate.
    """
    frame = survival_frame(data.rename(columns={T: 'T', E: 'E'}), [xcol] + cov, 'T', 'E')
    cph = cox_summary(frame)
    s = cph.summary.loc[xcol]
    return (np.exp(s['coef'] * sd), np.exp(s['coef lower 95%'] * sd),
            np.exp(s['coef upper 95%'] * sd), float(s['p']), len(frame),
            int(frame['E'].sum()))


def interaction_p(data, var, T, E, cov):
    """P value of the product term APAR x `var` in a Model 3 that also
    contains the main effect of `var`."""
    d = data.copy()
    d['_int'] = d['apar'] * d[var]
    frame = survival_frame(d.rename(columns={T: 'T', E: 'E'}),
                           ['apar', var, '_int'] + [c for c in cov if c != var], 'T', 'E')
    cph = cox_summary(frame)
    return cph, frame, float(cph.summary.loc['_int', 'p'])


# `e_value()` is NOT defined here: it lives in apar_common so that every
# script shares one implementation.  Two independent copies used to exist and
# they disagreed - see the note in apar_common.e_value for the details.


def row(label, hz, est, events=None, note=''):
    """One Table S5 row.

    `events` defaults to the number of events **inside the fitted subset**
    (est[5]), so that N and Events always describe the same patients.
    """
    return dict(Sensitivity=label, Horizon=hz, N=est[4],
                Events=est[5] if events is None else events,
                Estimate=est[0], lo=est[1], hi=est[2], P=est[3], Note=note)


def load_aux(path, key, cols=None):
    """Read a small auxiliary CSV; return None (and warn) if it is unavailable."""
    if not path or not os.path.exists(path):
        print(f'  [skip] {key}: {path} not found')
        return None
    d = pd.read_csv(path)
    return d if cols is None else d[cols]


def main():
    parser = common_args(__doc__)
    parser.add_argument('--cc-stay',
                        default=resolve_path('cc_stay.csv', 'APAR_CC_STAY'),
                        help='stay_id, cc  (complete cases of the raw extract)')
    parser.add_argument('--albumin',
                        default=resolve_path('albumin_before_draw.csv', 'APAR_ALBUMIN'),
                        help='stay_id, before  (albumin infused before the index draw)')
    parser.add_argument('--dsofa',
                        default=resolve_path('dsofa_cohort.csv', 'APAR_DSOFA'),
                        help='stay_id, baseline_sofa, dsofa')
    parser.add_argument('--anchor',
                        default=resolve_path('anchor_year_group.csv', 'APAR_ANCHOR'),
                        help='subject_id, anchor_year_group')
    parser.add_argument('--biliary',
                        default=resolve_path('biliary.csv', 'APAR_BILIARY'),
                        help='stay_id, biliary_obs  (coded biliary obstruction/cholangitis)')
    parser.add_argument('--cohort-incl24h',
                        default=resolve_path('cohort_v2_incl24hdeath_raw.csv',
                                             'APAR_COHORT_INCL24H'),
                        help='variant cohort that retains deaths within 24 h of ICU admission')
    parser.add_argument('--extras',
                        default=resolve_path('cohort_v2_extras.csv', 'APAR_EXTRAS'),
                        help='extraction output that carries the draw timestamps')
    args = parser.parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    m, sc = load_cohort(args.cohort, args.derived)
    SD = sc['SD_apar']

    # ---------------------------------------------------------- subsets
    cc = load_aux(args.cc_stay, 'complete-case subset')
    alb = load_aux(args.albumin, 'albumin infusion')
    dso = load_aux(args.dsofa, 'baseline-corrected SOFA')
    anc = load_aux(args.anchor, 'anchor year group')

    if cc is not None:
        cc_stays = set(cc.loc[cc['cc'].astype(str).str.lower() == 'true', 'stay_id'])
        m['_cc'] = m['stay_id'].isin(cc_stays)
    if alb is not None:
        m = m.merge(alb[['stay_id', 'before']].rename(columns={'before': '_alb_before'}),
                    on='stay_id', how='left')
        m['_alb_before'] = m['_alb_before'].fillna(False).astype(bool)
    if dso is not None:
        m = m.merge(dso[['stay_id', 'baseline_sofa', 'dsofa']], on='stay_id', how='left')
        m['_dsofa_fail'] = m['baseline_sofa'].notna() & (m['dsofa'] < 2)
    if anc is not None:
        m = m.merge(anc, on='subject_id', how='left')
        m['_y2020'] = m['anchor_year_group'].astype(str).str.strip() == '2020 - 2022'
    bil = load_aux(args.biliary, 'biliary obstruction')
    if bil is not None:
        m = m.merge(bil[['stay_id', 'biliary_obs']], on='stay_id', how='left')
        m['biliary_obs'] = m['biliary_obs'].fillna(0).astype(int)

    rows = []
    for hz, T, E, _ in HORIZONS:
        # ------------------------------------------------------- primary analysis
        prim = q4_vs_q1(m, T, E, ADJ)
        rows.append(row('Primary analysis (Model 3, Q4 vs Q1)', hz, prim))

        # ------------------------------------------------ complete-case analysis
        if cc is not None:
            est = q4_vs_q1(m[m['_cc']], T, E, ADJ)
            rows.append(row('Complete-case analysis (Q4 vs Q1)', hz, est))

        # ------------------------------------- 1. APAR above mean + 3 SD dropped
        thr = m['apar'].mean() + 3 * SD
        sub = m[m['apar'] <= thr]
        rows.append(row('1. APAR > mean + 3 SD excluded (Q4 vs Q1)', hz,
                        q4_vs_q1(sub, T, E, ADJ), note=f'threshold = {thr:.2f}'))

        # --------------------------------------------- 2. winsorized 1st/99th
        lo_q, hi_q = m['apar'].quantile(.01), m['apar'].quantile(.99)
        w = m.copy()
        w['apar'] = w['apar'].clip(lo_q, hi_q)
        rows.append(row('2. APAR winsorized 1/99 (Q4 vs Q1)', hz,
                        q4_vs_q1(w, T, E, ADJ),
                        note=f'clip [{lo_q:.2f}, {hi_q:.2f}]'))

        # -------------------------------------------------- 3. log2(APAR), per doubling
        lg = m.copy()
        lg['log2apar'] = np.log2(lg['apar'])
        frame = survival_frame(lg.rename(columns={T: 'T', E: 'E'}),
                               ['log2apar'] + ADJ, 'T', 'E')
        cph = cox_summary(frame)
        s = cph.summary.loc['log2apar']
        rows.append(dict(Sensitivity='3. log2(APAR), HR per doubling', Horizon=hz,
                         N=len(frame), Events=int(frame['E'].sum()),
                         Estimate=s['exp(coef)'], lo=s['exp(coef) lower 95%'],
                         hi=s['exp(coef) upper 95%'], P=float(s['p']), Note=''))

        # --------------------------------------------- 4a/4b ALP and albumin alone
        # ALP is reported in IU/L, albumin in g/L; the stored ALB column is g/dL
        for col, lab in [('ALP', '4a. ALP alone, per 1 SD'),
                         ('ALB', '4b. Albumin alone, per 1 SD')]:
            est = per_sd(m, col, T, E, ADJ)
            sd = (albumin_to_gl(m[col]).std(ddof=1) if col == 'ALB'
                  else m[col].std(ddof=1))
            rows.append(row(lab, hz, est, note=f'SD = {sd:.3f}'))

        # ------------------------------- 5. albumin infused before the index draw
        if alb is not None:
            sub = m[~m['_alb_before']]
            rows.append(row('5. Excluding albumin infusion before index draw (Q4 vs Q1)',
                            hz, q4_vs_q1(sub, T, E, ADJ),
                            note='albumin itemids 220861-220864, 220574, 227456'))

        # -------------------------------------------- 6. biliary obstruction excluded
        sub = m[m.get('biliary_obs', 0) != 1]
        rows.append(row('6. Excluding biliary obstruction / cholangitis (Q4 vs Q1)',
                        hz, q4_vs_q1(sub, T, E, ADJ)))

        # ------------------------- 7. sepsis redefined by a baseline-corrected SOFA
        if dso is not None:
            # 7 is the cohort of Supplementary Table S5 row 7: the 1,102 patients
            # without a computable baseline are RETAINED (a baseline is not
            # applicable rather than unmeasured), the 381 with a computable
            # baseline who did not reach the >= 2 rise are excluded.
            # 1,865 - 381 = 1,484; 1,459 complete.
            sub = m[~m['_dsofa_fail'].fillna(False)]
            rows.append(row('7. Sepsis by baseline-corrected SOFA rise >= 2 (Q4 vs Q1)',
                            hz, q4_vs_q1(sub, T, E, ADJ)))

            # 7b is the strict reading of the same criterion: fit ONLY the patients
            # who demonstrably met it.  382 patients have a computable baseline and
            # a rise of >= 2, but 3 of them lack MELD-Na, so the fitted subset is
            # 379 - this is the 382 -> 379 step quoted in the Table S5 footnote.
            # Q4 vs Q1 is cut inside `strict`, i.e. within these 379 patients.
            strict = m[m['baseline_sofa'].notna() & (m['dsofa'] >= 2)]
            est9b = q4_vs_q1(strict, T, E, ADJ)
            rows.append(row('7b. Baseline-corrected SOFA, patients meeting the criterion only (Q4 vs Q1)',
                            hz, est9b,
                            note=(f'{len(strict)} met dSOFA >= 2; {est9b[4]} fitted '
                                  f'(complete cases; {len(strict) - est9b[4]} lacked MELD-Na)')))

            # 7c is the formal test quoted in the same footnote.  It is fitted in
            # ALL complete cases (1,831), NOT in the 379-patient subset of 7b:
            # the product term needs both levels of baseline availability, and
            # the 7b subset contains only patients who have one.
            m['_has_base'] = m['baseline_sofa'].notna().astype(float)
            _, frame9c, p_int9c = interaction_p(m, '_has_base', T, E, ADJ)
            rows.append(dict(
                Sensitivity='7c. P for interaction (baseline availability x APAR, not an HR)',
                Horizon=hz, N=len(frame9c), Events=int(frame9c['E'].sum()),
                Estimate=np.nan, lo=np.nan, hi=np.nan, P=p_int9c,
                Note=('all 1,831 complete cases; Model 3 + baseline indicator + '
                      'product term; not the 379-patient subset of row 7b')))

        # ----------------------------------------------------------- 8. E-value
        rows.append(dict(Sensitivity='8. E-value (point estimate / CI limit)',
                         Horizon=hz, N=None, Events=None,
                         Estimate=e_value(prim[0]), lo=e_value(prim[1]),
                         hi=np.nan, P=np.nan, Note='derived from the primary Q4 vs Q1 estimate'))

        # ------------------------------------------- 9. admissions from 2020 onwards
        if anc is not None:
            sub = m[~m['_y2020'].fillna(False)]
            rows.append(row('9. Excluding admissions from 2020 onwards (Q4 vs Q1)',
                            hz, q4_vs_q1(sub, T, E, ADJ)))

    # ------- 10. additional adjustment for the white-cell count (M4)
    # Lactate is NOT added here: it is missing in 18.5% of the cohort and the
    # Methods state that variables with >15% missingness do not enter the
    # multivariable models (Supplementary Table S1).
    for hz, T, E, _ in HORIZONS:
        est = q4_vs_q1(m, T, E, ADJ + ['wbc'])
        rows.append(row('10. Further adjusted for the white-cell count (M4, Q4 vs Q1)',
                        hz, est))

    # ------------------- 11. cohort including deaths within 24 h of ICU admission
    try:
        d2 = pd.read_csv(args.cohort_incl24h)
        d2['apar'] = apar_from(d2['ALP'], d2['ALB'])   # ALB stored as g/dL
        if d2['gender_recode'].dtype == object:
            d2['gender'] = (d2['gender_recode'].astype(str).str.upper() == 'M').astype(int)
        else:
            d2['gender'] = d2['gender_recode']
        d2['alcohol'] = d2['alcohol_flag']
        inr2 = d2['first_inr']
        # Same OPTN bounds as the main cohort (creatinine cap 4.0, sodium
        # clamped to [125, 137]) - meld_na_from() is the single implementation.
        d2['meld_na'] = meld_na_from(d2['first_creatinine'],
                                     d2['first_bilirubin_total'], inr2,
                                     d2['first_sodium'])
        # SD of the retained cohort, computed once: it is what the per-1-SD
        # reading below is scaled by, and it is also the number quoted in the
        # Table S5 footnote (4.98).
        sd2 = float(d2['apar'].std(ddof=1))
        for hz, T, E in [('30d', 'survival_days_30', 'death_within_icu_30days'),
                         ('90d', 'survival_days_90', 'death_within_hosp_90days')]:
            # Per 1 unit (1 IU/L per g/L), NOT per 1 SD and NOT Q4 vs Q1.
            #   (i) every additionally retained patient dies inside the first
            #       24 h of follow-up, so a quartile contrast would be dominated
            #       by those immediate events;
            #   (ii) the retained cohort has a wider APAR distribution than the
            #       analysis cohort (SD 4.98 vs 4.71), so per-1-SD estimates are
            #       NOT comparable across cohorts - the entire apparent gap
            #       between them is a scaling artefact. Per unit the hazards are
            #       nearly identical (1.036 vs 1.036 at 30 days).
            est = per_sd_at(d2, 'apar', T, E, ADJ, 1.0)
            # The same fitted model read on the per-1-SD scale.  Not the
            # headline number, for the reason in (ii), but it is quoted in the
            # Table S5 footnote and must therefore be produced by the code.
            est_sd = per_sd_at(d2, 'apar', T, E, ADJ, sd2)
            # Two different Ns, kept apart on purpose: the retained 24-h cohort
            # has 1,927 rows, but the model is fitted on its 1,891 complete
            # cases. The SD likewise refers to the retained cohort.
            rows.append(row('11. Including deaths within 24 h of ICU admission, per 1 unit',
                            hz, est,
                            note=(f'retained cohort N = {len(d2)}; '
                                  f'analysed N = {est[4]} (complete cases); '
                                  f'SD = {sd2:.3f}; the same model read per 1 SD '
                                  f'gives {est_sd[0]:.3f} ({est_sd[1]:.3f}-'
                                  f'{est_sd[2]:.3f})')))
    except Exception as e:
        print('  [skip] cohort retaining deaths within 24 h:', e)

    # ------------------------------------------- shared timing extract (rows 12, 13)
    # Rows 12 and 13 both need the moment APAR becomes computable - the later of
    # the two index draws - and its position relative to sepsis onset, so the
    # extract is read once here.
    mm = None
    try:
        exs = pd.read_csv(args.extras)
        exs['idx_h'] = exs[['alp_h_from_icu', 'alb_h_from_icu']].apply(
            pd.to_numeric, errors='coerce').max(axis=1)
        exs['onset_h'] = (pd.to_datetime(exs['sofa_time'])
                          - pd.to_datetime(exs['icu_intime'])).dt.total_seconds() / 3600.0
        mm = m.merge(exs[['stay_id', 'idx_h', 'onset_h']], on='stay_id', how='left')
        n_nodraw = int(mm['idx_h'].isna().sum())
        if n_nodraw:
            print(f'  [warn] {n_nodraw} patients without a draw timestamp')
        mm = mm.dropna(subset=['idx_h'])
        mm['_after_onset'] = (mm['idx_h'] - mm['onset_h'] >= 0).astype(int)
        n_noonset = int(mm['onset_h'].isna().sum())
        if n_noonset:
            print(f'  [warn] {n_noonset} patients without a sepsis-onset timestamp')
    except Exception as e:
        print('  [skip] timing extract:', e)

    # ------------------- 12. time origin moved from ICU admission to the index draw
    # Immortal-time sensitivity analysis.  In the primary analysis the clock
    # starts at ICU admission, but APAR only becomes computable at the later of
    # the two draws; the interval in between (median 2.47 h) is time during
    # which a death cannot be attributed to a not-yet-measured exposure.  Here
    # the survival time is re-expressed on an hourly scale running from the
    # index draw, so every patient is at risk only from the moment APAR exists.
    if mm is not None:
        for hz, T, E, days in HORIZONS:
            mm['_T_draw'] = np.clip(np.where(mm[E] == 1,
                                             mm['days_to_death'] * 24.0 - mm['idx_h'],
                                             days * 24.0 - mm['idx_h']),
                                    0.05, None)
            est = q4_vs_q1(mm, '_T_draw', E, ADJ)
            rows.append(row('12. Time origin moved to the index draw (Q4 vs Q1)',
                            hz, est,
                            note='clock starts when APAR becomes computable'))

    # ------------------- 13. stratified by index draw before / after sepsis onset
    # Asked by the review: the index draw and sepsis onset overlap in time, so
    # the exposure is measured before the defining event in roughly half the
    # cohort.  If that overlap mattered, the association would differ between
    # the two timing strata; 13a / 13b are the two stratum-specific estimates
    # and 13c is the formal test of their difference.
    if mm is not None:
        d15 = mm.dropna(subset=['onset_h']).copy()
        for hz, T, E, _ in HORIZONS:
            for g, lab in [(0, 'before sepsis onset'), (1, 'after sepsis onset')]:
                est = per_sd_at(d15[d15['_after_onset'] == g], 'apar', T, E, ADJ, SD)
                rows.append(row(f'13{"ab"[g]}. Index draw {lab}, per 1 SD', hz, est,
                                note=f'SD = {SD:.3f} (whole cohort); Model 3'))
            _, frame, p_int = interaction_p(d15, '_after_onset', T, E, ADJ)
            rows.append(dict(
                Sensitivity='13c. P for interaction (draw timing x APAR, not an HR)',
                Horizon=hz, N=len(frame), Events=int(frame['E'].sum()),
                Estimate=np.nan, lo=np.nan, hi=np.nan, P=p_int,
                Note='Model 3 + timing indicator + product term'))

    # ------------------- 14. INR approximated as PT / 11.0 s
    # Raised during review: INR cannot be replaced by PT / 11.0 s unless the
    # international sensitivity index is 1 and 11.0 s happens to be the
    # laboratory's normal mean prothrombin time.  In MIMIC-IV neither holds -
    # the reported INR (item 51237) implies a normal mean PT with a median of
    # 10.889 s - so the primary analysis uses the reported INR throughout, and
    # the ACLF coagulation criterion has always done so.  This row repeats
    # Model 3 with the older PT / 11.0 s approximation so that the effect of
    # that choice can be read directly: the two INR definitions correlate at
    # r = 0.9722 and the resulting MELD-Na at r = 0.99928.
    m16 = m.copy()
    inr16 = m16['first_pt'] / 11.0
    m16['meld_na'] = meld_na_from(m16['first_creatinine'],
                                  m16['first_bilirubin_total'], inr16,
                                  m16['first_sodium'])
    for hz, T, E, _ in HORIZONS:
        est = q4_vs_q1(m16, T, E, ADJ)
        rows.append(row('14. INR approximated as PT / 11.0 s (Q4 vs Q1)', hz, est,
                        note=('sensitivity to the INR definition; the primary '
                              'analysis uses the reported INR (item 51237)')))

    # ------------------- 15. brain criterion on the whole ICU stay
    # The review asked whether the brain component of ACLF should be allowed to
    # use information from after the baseline window.  In the primary analysis
    # it now may not: every component, brain included, is scored inside the
    # first 24 h.  This row re-imposes the whole-stay window and re-derives the
    # failure count, the ACLF indicator and the Model 3 estimate from it.
    OFS = ['of_liver', 'of_kidney', 'of_coagulation', 'of_circulation',
           'of_brain', 'of_respiratory']
    m17 = m.copy()
    m17['of_brain'] = (m17['gcs_whole'] <= 8).fillna(False).astype(int)
    m17['of_count'] = m17[OFS].sum(axis=1)
    m17['aclf_binary'] = (m17['of_count'] >= 1).astype(int)
    n_wide = int((m17['of_brain'] == 1).sum())
    n_narrow = int((m['of_brain'] == 1).sum())
    for hz, T, E, _ in HORIZONS:
        est = q4_vs_q1(m17, T, E, ADJ)
        rows.append(row('15. Brain-failure criterion over the whole ICU stay (Q4 vs Q1)',
                        hz, est,
                        note=(f'brain failure in {n_wide} vs {n_narrow} patients; '
                              f'primary analysis uses the 24-h minimum GCS')))

    t5 = pd.DataFrame(rows)
    t5.to_csv(f'{args.outdir}/TableS5_sensitivity.csv', index=False, encoding='utf-8-sig')

    pd.set_option('display.width', 250)
    pd.set_option('display.max_colwidth', 56)
    print('===== Supplementary Table S5 =====')
    print(t5[['Sensitivity', 'Horizon', 'N', 'Estimate', 'lo', 'hi', 'P']].to_string(index=False))
    print('\nOutputs written to', args.outdir)


if __name__ == '__main__':
    main()
