"""
Baseline characteristics: Table 1 of the manuscript.

Patients are described overall and by 30-day vital status.  Continuous
variables are summarised as median (interquartile range) and compared with a
two-sided Mann-Whitney U test; categorical variables are summarised as n (%)
and compared with a chi-square test, or with Fisher's exact test when any
expected count was below 5.  The row order and labels follow Table 1 of the
manuscript exactly.
"""
import os

import numpy as np
import pandas as pd
from scipy import stats

from apar_common import E30, common_args, load_cohort


def median_iqr(s):
    s = pd.Series(s).dropna()
    if len(s) == 0:
        return '-'
    return f'{s.median():.1f} ({s.quantile(0.25):.1f}-{s.quantile(0.75):.1f})'


def n_pct(mask):
    mask = pd.Series(mask).dropna()
    k = int(mask.sum())
    n = len(mask)
    return f'{k} ({k / n * 100:.1f}%)' if n else '-'


def p_cont(df, var):
    a = df.loc[df[E30] == 0, var].dropna()
    b = df.loc[df[E30] == 1, var].dropna()
    if len(a) < 3 or len(b) < 3:
        return '-'
    try:
        _, p = stats.mannwhitneyu(a, b, alternative='two-sided')
    except Exception:
        return '-'
    return f'{p:.3f}' if p >= 0.001 else '<0.001'


def p_cat(df, var):
    """Chi-square test, replaced by Fisher's exact test when any expected
    count is below 5 (as stated in Statistical analysis, section 2.7)."""
    try:
        ct = pd.crosstab(df[var], df[E30])
        if ct.shape[0] < 2 or ct.shape[1] < 2:
            return '-'
        _, p, _, expected = stats.chi2_contingency(ct)
        if expected.min() < 5:
            # scipy >= 1.9 supports R x C tables in fisher_exact
            _, p = stats.fisher_exact(ct.values)
    except Exception:
        return '-'
    return f'{p:.3f}' if p >= 0.001 else '<0.001'


def main():
    parser = common_args(__doc__)
    args = parser.parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    m, sc = load_cohort(args.cohort, args.derived)
    # Reported INR (MIMIC-IV item 51237), not PT / 11.0 s.  Identical to the
    # convention used for MELD-Na in apar_common.py.  Prothrombin time itself
    # is reported separately two rows below, so both remain available.
    m['INR'] = m['first_inr']

    rows = []          # (Section, Variable, spec)
    # spec: ('cont', column) | ('bin', column, positive_label) | ('level', column, value)
    rows += [
        ('Demographics', 'Age, years', ('cont', 'age')),
        ('Demographics', 'Male sex, n (%)', ('bin', 'gender_recode')),
        ('Demographics', 'SOFA score', ('cont', 'sofa')),
        ('Liver-specific severity scores', 'MELD score', ('cont', 'meld_plain')),
        ('Liver-specific severity scores', 'MELD-Na score', ('cont', 'meld_na')),
        ('Cirrhosis characteristics', 'Alcohol-related aetiology, n (%)', ('bin', 'alcohol')),
        ('Cirrhosis characteristics', 'Other (non-alcoholic) aetiology, n (%)', ('neg', 'alcohol')),
        ('Cirrhosis characteristics', 'ACLF at admission (>=1 organ failure), n (%)',
         ('bin', 'aclf_binary')),
        ('Cirrhosis characteristics', 'No ACLF, n (%)', ('level', 'aclf_grade', 'No ACLF')),
        ('Cirrhosis characteristics', 'ACLF grade 1, n (%)', ('level', 'aclf_grade', 'ACLF-1')),
        ('Cirrhosis characteristics', 'ACLF grade 2, n (%)', ('level', 'aclf_grade', 'ACLF-2')),
        ('Cirrhosis characteristics', 'ACLF grade 3, n (%)', ('level', 'aclf_grade', 'ACLF-3')),
        ('Laboratory parameters', 'Hemoglobin, g/dL', ('cont', 'first_hemoglobin')),
        ('Laboratory parameters', 'Platelet count, K/uL', ('cont', 'first_platelet_count')),
        ('Laboratory parameters', 'White blood cell count, x10^9/L',
         ('cont', 'first_white_blood_cells')),
        ('Laboratory parameters', 'pH', ('cont', 'first_ph')),
        ('Laboratory parameters', 'Lactate, mmol/L', ('cont', 'first_lactate')),
        ('Laboratory parameters', 'ALT, IU/L', ('cont', 'first_alanine_aminotransferase_alt')),
        ('Laboratory parameters', 'AST, IU/L', ('cont', 'first_asparate_aminotransferase_ast')),
        ('Laboratory parameters', 'Total bilirubin, mg/dL', ('cont', 'first_bilirubin_total')),
        ('Laboratory parameters', 'Creatinine, mg/dL', ('cont', 'first_creatinine')),
        ('Laboratory parameters', 'Sodium, mmol/L', ('cont', 'first_sodium')),
        ('Laboratory parameters', 'Prothrombin time, s', ('cont', 'first_pt')),
        ('Laboratory parameters', 'INR', ('cont', 'INR')),
        ('Laboratory parameters', 'Albumin, g/L', ('cont', 'albumin_gl')),
        ('Laboratory parameters', 'ALP, IU/L', ('cont', 'ALP')),
        ('Laboratory parameters', 'APAR', ('cont', 'apar')),
        ('Comorbidities', 'Acute kidney injury, n (%)', ('bin', 'aki')),
        ('Outcomes', 'In-hospital mortality, n (%)', ('bin', 'death_in_current_adm')),
        ('Outcomes', 'ICU mortality, n (%)', ('bin', 'is_icu_dead')),
    ]

    alive = m[m[E30] == 0]
    dead = m[m[E30] == 1]
    out = []
    for section, label, spec in rows:
        kind = spec[0]
        col = spec[1]
        if kind == 'cont':
            vals = [median_iqr(g[col]) for g in (m, alive, dead)]
            p = p_cont(m, col)
        elif kind in ('bin', 'neg'):
            pos = spec[0] == 'bin'
            vals = [n_pct(g[col] == 1 if pos else g[col] == 0) for g in (m, alive, dead)]
            p = p_cat(m, col) if pos else ''
        else:                                       # level of a categorical column
            val = spec[2]
            vals = [n_pct(g[col] == val) for g in (m, alive, dead)]
            p = ''
        out.append(dict(Section=section, Variable=label, All=vals[0],
                        Survivors_30d=vals[1], NonSurvivors_30d=vals[2],
                        P_value=p))

    tab = pd.DataFrame(out)
    tab.to_csv(f'{args.outdir}/Table1_baseline.csv', index=False, encoding='utf-8-sig')

    pd.set_option('display.width', 220)
    pd.set_option('display.max_colwidth', 46)
    print(f"N = {sc['N']} | 30-day events = {sc['events_30d']}")
    print(tab.to_string(index=False))
    print('\nWritten to', args.outdir)


if __name__ == '__main__':
    main()
