"""
Shared definitions for the APAR (alkaline phosphatase-to-albumin ratio) analysis.

Every module in this package uses exactly the same pipeline, so all reported
numbers are mutually consistent.

Cohort
------
Critically ill patients with cirrhosis and sepsis in MIMIC-IV v3.1, N = 1,865.
The cohort is extracted (see README.md and sql/) into `data/cohort_v2.xlsx`;
aetiology / ACLF / organ-failure flags are derived separately into
`data/derived_v2.xlsx`.

Inputs are located by :func:`resolve_path`, so the package is portable: point
the environment variables APAR_COHORT / APAR_DERIVED / APAR_OUTDIR (or the
`--cohort` / `--derived` / `--outdir` flags) anywhere you like, or simply drop
the two spreadsheets into `data/`.

Entry criteria: cirrhosis (ICD, any position), Sepsis-3, age >= 18; one ICU
stay per patient, the earliest stay at which Sepsis-3 criteria were met.  ALP and albumin must both be measured within 24 h of ICU
admission (each analyte contributes its own first value in that window); death
within 24 h of ICU admission is excluded.  Every covariate is the first
measurement inside the same 24 h window.  Patients with no value for a model
covariate are dropped from that model (complete-case analysis).

Key conventions
---------------
* APAR = serum ALP (IU/L) / serum albumin (**g/L**).  MIMIC-IV reports albumin
  in g/dL, so the stored value is multiplied by 10 before the division; use
  :func:`apar_from` so every module applies the same convention.
  Albumin itself is reported in g/L throughout the manuscript and tables
  (`albumin_gl` column), i.e. 10 x the value stored in the extraction.
* INR is the laboratory-reported international normalised ratio (MIMIC-IV
  item 51237), not the approximation PT / 11.0 s.  See the comment above
  `inr = m['first_inr']` in `load_cohort()` for why the two differ, and
  `07_sensitivity.py` (row "16. INR approximated as PT / 11.0 s") for the
  retained sensitivity analysis.
* MELD uses the UNOS convention (creatinine 1-4, bilirubin and INR floored at 1,
  MELD floored at 0); MELD-Na adds the UNOS sodium term and is capped at 40.
* Horizons: 30-day mortality (ICU-based follow-up) and 90-day mortality
  (hospital-based follow-up).
"""
import argparse
import os

import numpy as np
import pandas as pd

# ---------------------------------------------------------------- paths
# Paths are resolved portably so the package runs unchanged on any machine.
#   package root/
#     apar_common.py, 00_*.py ... 11_*.py     <- the code
#     data/                                   <- inputs you generate yourself
#     results/                                <- outputs (shipped, reproducible)
#     sql/                                    <- queries that build data/
PKG_ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(PKG_ROOT, 'data')

# Optional last-resort fallback: set APAR_LEGACY_DIR to a directory holding the
# same file names (e.g. the author's extraction folder) and it will be used only
# when the corresponding file is absent from the package.  Unset by default, so
# the distributed package contains no absolute path at all.
LEGACY_DATA_DIR = os.environ.get('APAR_LEGACY_DIR', '')


def resolve_path(filename, env_var=None, subdir='data'):
    """Locate a file without hard-coding any absolute path.

    Precedence
    ----------
    1. environment variable `env_var` (e.g. ``APAR_COHORT=/data/cohort.xlsx``);
    2. ``<package root>/<subdir>/<filename>``  (the portable default);
    3. ``$APAR_LEGACY_DIR/<filename>``  — optional fallback directory holding the
       same file names, for anyone who keeps the inputs elsewhere.

    ``~`` and relative paths given through the environment variable are
    expanded.  Nothing is created here; use :func:`resolve_outdir` for outputs.
    If none of the three exists, the in-package location is returned so that the
    ensuing error message (or the corresponding command-line flag) names a
    sensible path.
    """
    if env_var:
        v = os.environ.get(env_var)
        if v:
            return os.path.abspath(os.path.expanduser(v))
    p = os.path.join(PKG_ROOT, subdir, filename)
    if os.path.exists(p):
        return p
    if LEGACY_DATA_DIR:
        legacy = os.path.join(LEGACY_DATA_DIR, filename)
        if os.path.exists(legacy):
            return legacy
    return p


def resolve_outdir(subdir='results', env_var='APAR_OUTDIR'):
    """Locate (and create) the output directory."""
    v = os.environ.get(env_var) if env_var else None
    if v:
        p = os.path.abspath(os.path.expanduser(v))
    else:
        p = os.path.join(PKG_ROOT, subdir)
    os.makedirs(p, exist_ok=True)
    return p


# --------------------------------------------------------------- units
# MIMIC-IV stores albumin as g/dL; the manuscript reports g/L.
ALB_GDL_TO_GL = 10.0


def albumin_to_gl(albumin_g_dl):
    """Albumin g/dL -> g/L."""
    return albumin_g_dl * ALB_GDL_TO_GL


def apar_from(alp_iu_l, albumin_g_dl):
    """APAR = ALP (IU/L) / albumin (g/L).

    `alp_iu_l` and `albumin_g_dl` are exactly as they come out of MIMIC-IV
    (albumin in g/dL); the conversion is applied here so that no caller has to
    remember it, and so that a change of convention cannot silently
    desynchronise one analysis from another.
    """
    return alp_iu_l / (albumin_g_dl * ALB_GDL_TO_GL)


# ---------------------------------------------------------------- MELD / MELD-Na
# The 2016 OPTN (UNOS) allocation score, implemented in full.  Every bounding
# rule of OPTN Policy 9 (effective January 2016) is applied:
#
#   * creatinine, total bilirubin and INR are FLOORED at 1.0
#         Cr_c   = min( max(creatinine, 1.0), 4.0 )   -- floor then ceiling
#         Bili_c = max(bilirubin, 1.0)
#         INR_c  = max(INR, 1.0)
#   * creatinine is CAPPED at 4.0 mg/dL (values above 4.0 are set to 4.0)
#   * sodium is clamped to [125, 137] mmol/L
#         Na_clipped = min(137, max(125, Na))
#         values <= 125 -> 125 ;  values >= 137 -> 137   (both ends inclusive)
#   * the sodium term is applied ONLY when MELD(i) > 11
#   * the final score is capped at 40 (and floored at 0 by construction)
#
#     MELD(i)  = max( 0.957*ln(Cr_c) + 0.378*ln(Bili_c) + 1.120*ln(INR_c)
#                     + 0.643 , 0 ) * 10
#     MELD-Na  = min( max( MELD(i) + [MELD(i) > 11]
#                          * ( 1.32*(137-Na_c) - 0.033*MELD(i)*(137-Na_c) ), 0 ), 40 )
#
# The single deviation from the allocation rule is that MELD(i) is NOT rounded
# to an integer: it is kept continuous because it is used as a continuous
# covariate and as a subgrouping variable.  The same holds for the SQL in
# Supplementary File 1, which now uses the identical bounds.
LAB_FLOOR = 1.0              # OPTN floor for creatinine / bilirubin / INR
CR_CAP = 4.0                 # OPTN creatinine ceiling, mg/dL
NA_LO, NA_HI = 125.0, 137.0  # OPTN sodium window, mmol/L
NA_GATE_MELD = 11.0          # sodium term applies only when MELD(i) > 11
MELD_NA_CAP = 40.0           # OPTN final score ceiling


def meld_from(creatinine, bilirubin, inr):
    """2016 OPTN MELD(i): labs floored at 1.0, creatinine capped at 4.0."""
    cr = np.clip(np.asarray(creatinine, dtype=float), LAB_FLOOR, CR_CAP)
    bili = np.maximum(np.asarray(bilirubin, dtype=float), LAB_FLOOR)
    i = np.maximum(np.asarray(inr, dtype=float), LAB_FLOOR)
    return np.maximum(0.957 * np.log(cr) + 0.378 * np.log(bili)
                      + 1.120 * np.log(i) + 0.643, 0) * 10


def meld_na_from(creatinine, bilirubin, inr, sodium):
    """2016 OPTN MELD-Na; sodium term applied only when MELD(i) > 11."""
    meld = meld_from(creatinine, bilirubin, inr)
    na_c = np.clip(np.asarray(sodium, dtype=float), NA_LO, NA_HI)
    add = np.where(meld > NA_GATE_MELD,
                   1.32 * (137.0 - na_c) - 0.033 * meld * (137.0 - na_c),
                   0.0)
    return np.clip(meld + add, 0, MELD_NA_CAP)


def _self_test_meld_bounds():
    """Guard every OPTN bound so a lost clamp cannot pass silently."""
    for na, want in [(99.0, 125.0), (120.0, 125.0), (124.0, 125.0),
                     (125.0, 125.0), (130.0, 130.0), (136.9, 136.9),
                     (137.0, 137.0), (140.0, 137.0), (158.0, 137.0)]:
        got = float(np.clip(na, NA_LO, NA_HI))
        assert got == want, f'sodium bound failed: Na={na} -> {got}, expected {want}'
    for cr, want in [(0.2, 1.0), (0.99, 1.0), (1.0, 1.0), (1.3, 1.3),
                     (3.9, 3.9), (4.0, 4.0), (4.1, 4.0), (18.1, 4.0)]:
        got = float(np.clip(cr, LAB_FLOOR, CR_CAP))
        assert got == want, f'creatinine bound failed: Cr={cr} -> {got}, expected {want}'
    for b, want in [(0.1, 1.0), (0.99, 1.0), (1.0, 1.0), (7.4, 7.4)]:
        got = float(np.maximum(b, LAB_FLOOR))
        assert got == want, f'bilirubin floor failed: Bili={b} -> {got}, expected {want}'
    for i, want in [(0.8, 1.0), (1.0, 1.0), (2.5, 2.5)]:
        got = float(np.maximum(i, LAB_FLOOR))
        assert got == want, f'INR floor failed: INR={i} -> {got}, expected {want}'
    # sodium term gated at MELD(i) > 11
    assert float(meld_na_from(1.0, 1.0, 1.0, 130.0)) == 6.43, 'gate failed below 11'
    assert abs(float(meld_na_from(2.0, 5.0, 1.8, 130.0))
               - float(meld_from(2.0, 5.0, 1.8)
                       + 1.32 * 7.0 - 0.033 * float(meld_from(2.0, 5.0, 1.8)) * 7.0)) < 1e-9


_self_test_meld_bounds()


# ---------------------------------------------------------------- outcomes
# READ THIS BEFORE "FIXING" THE NAMES BELOW.
# The event columns carry legacy labels from the earlier N = 2,209 extraction,
# where they genuinely denoted death in the ICU and death in hospital.  In the
# N = 1,865 cohort shipped here they are NOT setting-specific: both are
# ALL-CAUSE mortality computed from `patients.dod` in
# `sql/01_cohort_extraction.sql` STEP 7, lines 335-359:
#     death_30d = (p.dod - icu_intime::date) <= 30
#     death_90d = (p.dod - icu_intime::date) <= 90
# `patients.dod` merges hospital records with state death-registry records, so
# deaths occurring AFTER discharge are captured: 617 patients in this cohort
# have a dod later than the index discharge date and 239 of them die within
# 90 days.  In-hospital (505) and ICU (326) deaths are reported separately in
# Table 1 as supportive outcomes only.
# The legacy strings below are kept verbatim because they are the column names
# in data/cohort_v2.xlsx; renaming would desynchronise the delivered data file.
# Readable aliases - these are the semantically honest names:
ALL_CAUSE_DEATH_30D = 'death_30d'          # == 'death_within_icu_30days'
ALL_CAUSE_DEATH_90D = 'death_90d'          # == 'death_within_hosp_90days'

T30, E30 = 'survival_days_30', 'death_within_icu_30days'
T90, E90 = 'survival_days_90', 'death_within_hosp_90days'
HORIZONS = [('30d', T30, E30, 30), ('90d', T90, E90, 90)]

# ---------------------------------------------------------------- statistics


def e_value(hr):
    """VanderWeele-Ding E-value for a hazard ratio, on the risk-ratio scale.

    Mortality by the end of follow-up was 32.1% at 30 days and 40.5% at
    90 days, far above the 15% threshold below which a hazard ratio may be
    read as an approximate risk ratio.  The hazard ratio is therefore first
    converted to an approximate risk ratio (VanderWeele, Biometrics 2020)

        RR = (1 - 0.5**sqrt(HR)) / (1 - 0.5**sqrt(1 / HR))

    and only then is the E-value computed as

        E = RR + sqrt(RR * (RR - 1))

    This reproduces R's ``EValue::evalues.HR(rare = FALSE)``.

    DO NOT substitute the hazard ratio directly into E = HR + sqrt(HR*(HR-1)).
    That shortcut silently assumes a rare outcome; for the present estimates
    it inflates the E-value by roughly a quarter (2.76 instead of 2.22 at
    30 days and 3.11 instead of 2.43 at 90 days).  It was implemented once,
    independently, in ``01_main_models.py``, and the resulting
    ``results/e_value.csv`` disagreed with Table S5 for that reason alone.
    Every script must call this single shared implementation.
    """
    if hr <= 1:
        return np.nan
    rr = (1 - 0.5 ** np.sqrt(hr)) / (1 - 0.5 ** np.sqrt(1.0 / hr))
    return rr + np.sqrt(rr * (rr - 1))


# ---------------------------------------------------------------- covariates
ADJ = ['age', 'gender', 'meld_na', 'sofa', 'alcohol', 'aki', 'aclf_binary']
MODELS = {
    'M1': ['apar'],
    'M2': ['apar', 'age', 'gender', 'meld_na', 'sofa'],
    'M3': ['apar'] + ADJ,                              # primary model
    # M4 - extended sensitivity model.  Lactate is deliberately NOT entered:
    # it is missing in 18.5% of the cohort and the Methods state that variables
    # with more than 15% missingness are not entered into the multivariable
    # models (Supplementary Table S1).  Dropping it keeps every model on the
    # same complete-case sample, so M3 and M4 remain directly comparable.
    'M4': ['apar'] + ADJ + ['wbc'],
}

DEFAULT_COHORT = resolve_path('cohort_v2.xlsx', 'APAR_COHORT')
DEFAULT_DERIVED = resolve_path('derived_v2.xlsx', 'APAR_DERIVED')
DEFAULT_OUT = resolve_outdir('results', 'APAR_OUTDIR')


def load_cohort(cohort_xlsx=DEFAULT_COHORT, derived_xlsx=DEFAULT_DERIVED,
                alpha: float = 1e-6):
    """Load the analytic cohort and derive every variable used in the analyses.

    Returns (DataFrame, dict of scalars).  The DataFrame contains the original
    columns plus: apar, apar_col, meld_plain, meld_na, alcohol, gender,
    lactate, wbc, apar_q, apar_q_ord, age65, meldna20, sofa10.
    """
    cohort = pd.read_excel(cohort_xlsx)
    derived = pd.read_excel(derived_xlsx)
    m = cohort.merge(derived, on='stay_id', how='left', suffixes=('', '_der'))
    m = m.loc[:, ~m.columns.str.endswith('_der')]

    # Outcome sanity check.  'death_within_icu_30days' and
    # 'death_within_hosp_90days' are legacy column names (see the note above
    # the HORIZONS definition): despite the labels they hold ALL-CAUSE
    # mortality taken from `patients.dod`, identical to death_30d / death_90d.
    # Pin them row-for-row so that the endpoint described in Methods section
    # 2.5 can never silently diverge from what is actually modelled again.
    for _legacy, _canonical in (('death_within_icu_30days', 'death_30d'),
                                ('death_within_hosp_90days', 'death_90d')):
        if _legacy in m.columns and _canonical in m.columns:
            if not (m[_legacy].values == m[_canonical].values).all():
                raise AssertionError(
                    'outcome columns diverged: %s != %s' % (_legacy, _canonical))

    # APAR = ALP (IU/L) / albumin (g/L)
    if {'ALP', 'ALB'}.issubset(m.columns):
        # ALB is g/dL as stored in MIMIC-IV
        m['apar'] = apar_from(m['ALP'], m['ALB'])
    else:
        m['apar'] = m['ALP/ALB']
    m['apar_col'] = m['apar']

    # Albumin in g/L, the unit used for reporting throughout the manuscript
    if 'ALB' in m.columns:
        m['albumin_gl'] = albumin_to_gl(m['ALB'])
    elif 'first_albumin' in m.columns:
        m['albumin_gl'] = albumin_to_gl(m['first_albumin'])
    else:
        m['albumin_gl'] = np.nan

    # MELD and MELD-Na (identical to the convention used for Table 1).
    # Both bounds are the ones declared in Methods: creatinine capped at
    # 4.0 mg/dL and sodium clamped to [125, 137] mmol/L.  See meld_na_from().
    #
    # INR is the laboratory-reported value (MIMIC-IV item 51237), NOT the
    # approximation PT / 11.0 s.  The two differ (Pearson r = 0.9722; identical
    # in only 8.4% of patients) because each laboratory applies its own
    # international sensitivity index, and the normal mean PT implied by the
    # reported INR has a median of 10.889 s rather than 11.0 s.  The difference
    # is not a timing artefact: PT and INR come from the same charttime in
    # 1,831 of 1,833 patients (99.89%).  Using the reported INR also makes the
    # MELD-Na consistent with the ACLF coagulation criterion, which has always
    # used the reported INR (item 51237).
    #   The PT / 11.0 s variant is retained as a sensitivity analysis in
    #   Table S5 (07_sensitivity.py, row "INR approximated as PT / 11.0 s").
    inr = m['first_inr']
    meld_plain = meld_from(m['first_creatinine'],
                           m['first_bilirubin_total'], inr)
    m['meld_na'] = meld_na_from(m['first_creatinine'],
                                m['first_bilirubin_total'], inr,
                                m['first_sodium'])
    m['meld_plain'] = meld_plain

    m['alcohol'] = (m['aetiology'] == 'alcohol').astype(int)
    m['gender'] = m['gender_recode']
    m['wbc'] = m['first_white_blood_cells']
    m['lactate'] = m['first_lactate']

    # APAR quartiles
    m['apar_q'] = pd.qcut(m['apar'], 4, labels=['Q1', 'Q2', 'Q3', 'Q4'])
    m['apar_q_ord'] = pd.qcut(m['apar'], 4, labels=False) + 1

    # dichotomised covariates used for subgrouping
    m['age65'] = (m['age'] >= 65).astype(int)
    m['meldna20'] = (m['meld_na'] >= 20).astype(int)
    m['sofa10'] = (m['sofa'] >= 10).astype(int)

    scalars = dict(
        N=len(m),
        SD_apar=float(m['apar'].std(ddof=1)),
        SD_apar_col=float(m['apar_col'].std(ddof=1)),
        quartiles=[float(x) for x in np.percentile(m['apar'].dropna(), [25, 50, 75])],
        events_30d=int(m[E30].sum()),
        events_90d=int(m[E90].sum()),
        penalizer=alpha,
    )
    return m, scalars


def survival_frame(m, cols, T, E):
    """Restrict to complete rows and rename the outcome columns to T / E."""
    d = m[cols + [T, E]].dropna().rename(columns={T: 'T', E: 'E'})
    return d


def common_args(description):
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument('--cohort', default=DEFAULT_COHORT,
                        help='cohort spreadsheet (output of sql/01_cohort_extraction.sql); '
                             'default: $APAR_COHORT or ./data/cohort_v2.xlsx')
    parser.add_argument('--derived', default=DEFAULT_DERIVED,
                        help='derived covariates spreadsheet (aetiology, ACLF, organ failure); '
                             'default: $APAR_DERIVED or ./data/derived_v2.xlsx')
    parser.add_argument('--outdir', default=DEFAULT_OUT,
                        help='output directory; default: $APAR_OUTDIR or ./results')
    parser.add_argument('--n-boot', type=int, default=None,
                        help='override the number of bootstrap resamples')
    return parser
