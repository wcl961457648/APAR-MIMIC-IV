# Clean distribution package — analysis code only

This archive is the **redistributable** version of the analysis code that
supports the manuscript. It contains **no individual-level patient data**.

## What is included
- `*.py` — all analysis scripts (`00`–`13`, plus the shared `apar_common.py`)
- `sql/*.sql` — cohort extraction and sensitivity SQL for MIMIC-IV (PostgreSQL)
- `requirements.txt` — Python dependencies
- `README.md` — full reproduction instructions
- `data/README.md` — explains how to (re)generate the analysis inputs
- `results/*.csv` — all numerical results reported in the manuscript, as
  aggregate summary tables (no per-patient rows)

## What has been removed, and why
MIMIC-IV is a credentialed, patient-level resource. Under the PhysioNet Data
Use Agreement, individual-level data **may not be redistributed**. The working
directory therefore contained per-patient files that are deliberately **not**
shipped here:

- `data/cohort_v2_raw.csv`, `data/cohort_v2_extras.csv`,
  `data/cohort_v2_incl24hdeath_raw.csv` (1,866 rows x 78 columns, with
  `subject_id` / `stay_id` / `hadm_id`), `data/cohort_v2.xlsx`,
  `data/derived_v2.xlsx`
- `data/albumin_before_draw.csv`, `anchor_year_group.csv`, `biliary.csv`,
  `bmi.csv`, `cc_stay.csv`, `dsofa_cohort.csv` — 1,865 rows keyed by
  `stay_id` / `subject_id`
- rendered figure files (`*.tiff` / `*.png` / `*.pdf`, 13–23 MB each)
- editor backups (`_bak_*`) and interpreter caches (`__pycache__`)

## Reproducing the analysis
1. Obtain credentialed access to MIMIC-IV (CITI training + PhysioNet DUA).
2. Run `sql/01_cohort_extraction.sql` against `mimiciv_hosp` / `mimiciv_icu`
   to rebuild the cohort, then the remaining `sql/*.sql` for the sensitivity
   cohorts and ancillary variables.
3. `pip install -r requirements.txt` and run `00`–`13` in order; see
   `README.md` for the exact order and the mapping between scripts and
   manuscript tables/figures.

The `results/*.csv` files shipped here are the outputs of that pipeline and
correspond one-to-one with the numbers reported in the manuscript.
