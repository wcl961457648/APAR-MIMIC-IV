"""
Supplementary Table S2 - timing of the index measurements.

Five panels:
  A  interval from ICU admission to sepsis onset (Sepsis-3 SOFA time)
  B  interval from ICU admission to the first ALP draw (the index exposure)
  C  whether albumin was drawn at the same time as ALP
  D  interval from the index ALP draw to vasopressor initiation
     (negative values = treatment started before the draw)
  E  timing of the index draw relative to sepsis onset.  The index draw is the
     moment APAR becomes computable, i.e. the later of the first ALP and the
     first albumin draw; negative values mean the exposure was already
     available before Sepsis-3 criteria were met.  The last row answers the
     specific review question: among the patients whose albumin was drawn
     after ALP, how many had that albumin drawn after sepsis onset.

All panels are computed from the timestamps stored in
`data/cohort_v2_extras.csv`, which is written by the extraction script, so
this module needs no database access.

    python 10_timing.py
"""
import os

import numpy as np
import pandas as pd

from apar_common import common_args, load_cohort, resolve_path


def binned(series, edges, labels, total=None):
    counts = pd.cut(series, bins=edges, labels=labels,
                    right=False).value_counts().reindex(labels).fillna(0).astype(int)
    total = len(series) if total is None else total
    return [(lab, int(counts[lab]), 100 * counts[lab] / total) for lab in labels]


def med_iqr(s):
    s = pd.Series(s).dropna()
    return (float(s.median()), float(s.quantile(.25)), float(s.quantile(.75)), len(s))


def r2(x):
    """round to 2 decimals, but never return a signed zero."""
    v = round(float(x), 2)
    return 0.0 if v == 0 else v


def hours(a, b):
    """(a - b) in hours for two datetime columns."""
    return (pd.to_datetime(a) - pd.to_datetime(b)).dt.total_seconds() / 3600.0


def main():
    parser = common_args(__doc__)
    parser.add_argument('--extras',
                        default=resolve_path('cohort_v2_extras.csv', 'APAR_EXTRAS'),
                        help='extraction output that carries the timestamps')
    args = parser.parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    m, sc = load_cohort(args.cohort, args.derived)
    ex = pd.read_csv(args.extras)
    ex = ex[ex['stay_id'].isin(set(m['stay_id']))].copy()

    rows = []

    # ---------------------------------------------------------- Panel A
    t0 = hours(ex['sofa_time'], ex['icu_intime']).dropna()
    med, q1, q3, n = med_iqr(t0)
    rows.append(dict(Panel='A', Stratum='Overall (with sepsis onset time)',
                     n='', pct='', Median=round(med, 2), IQR=f'{q1:.2f}–{q3:.2f}'))
    for lab, c, p in binned(t0, [-np.inf, 0, 6, 12, 24, np.inf],
                            ['Before ICU admission (<0 h)', '0 to <6 h', '6 to <12 h',
                             '12 to <24 h', '≥24 h']):
        rows.append(dict(Panel='A', Stratum=lab, n=int(c), pct=f'{p:.1f}%',
                         Median='', IQR=''))

    # ---------------------------------------------------------- Panel B
    for panel, col, name in [('B', 'alp_h_from_icu', 'first ALP draw'),
                             ('B2', 'alb_h_from_icu', 'first albumin draw')]:
        s = pd.to_numeric(ex[col], errors='coerce').dropna()
        med, q1, q3, n = med_iqr(s)
        rows.append(dict(Panel=panel, Stratum=f'Overall ({name})', n='', pct='',
                         Median=round(med, 2), IQR=f'{q1:.2f}–{q3:.2f}'))
        for lab, c, p in binned(s, [0, 6, 12, 24, np.inf],
                                ['0 to <6 h', '6 to <12 h', '12 to <24 h', '≥24 h']):
            rows.append(dict(Panel=panel, Stratum=lab, n=int(c), pct=f'{p:.1f}%',
                             Median='', IQR=''))

    # ---------------------------------------------------------- Panel C
    # The lag is 0 by definition for the "same draw" stratum, so no median /
    # IQR is reported there; for the discordant strata the median and IQR are
    # conditional on belonging to that stratum.
    d = pd.to_numeric(ex['alb_alp_lag_h'], errors='coerce').dropna()
    for lab, sel, conditional in [
            ('Same draw (albumin at the same time as ALP)', d.abs() < 1e-9, False),
            ('Albumin drawn after ALP', d > 1e-9, True),
            ('Albumin drawn before ALP', d < -1e-9, True)]:
        k = int(sel.sum())
        med_txt = iqr_txt = ''
        if conditional and k:
            m_, q1_, q3_, _ = med_iqr(d[sel])
            med_txt, iqr_txt = round(m_, 2), f'{q1_:.2f}–{q3_:.2f}'
        rows.append(dict(Panel='C', Stratum=lab, n=k,
                         pct=f'{100 * k / len(d):.1f}%', Median=med_txt, IQR=iqr_txt))

    # ---------------------------------------------------------- Panel D
    alp_t = pd.to_datetime(ex['icu_intime']) + pd.to_timedelta(
        pd.to_numeric(ex['alp_h_from_icu'], errors='coerce'), unit='h')
    delta = hours(ex['vaso_time'], alp_t)
    first = delta.dropna()
    if len(first):
        # Median / IQR are stratum-specific: the "before" row summarises only
        # the patients whose vasopressor actually started before the draw.
        before = first[first < 0]
        mb, b1, b3, _ = med_iqr(before)
        rows.append(dict(Panel='D', Stratum='Vasopressor — initiated before the index draw',
                         n=f'{len(before)} of {len(first)}',
                         pct=f'{100 * len(before) / len(first):.1f}%',
                         Median=round(mb, 2), IQR=f'{b1:.2f}–{b3:.2f}'))
        med, q1, q3, n = med_iqr(first)
        rows.append(dict(Panel='D', Stratum='Vasopressor — all patients with a vasopressor',
                         n=len(first), pct='', Median=round(med, 2),
                         IQR=f'{q1:.2f}–{q3:.2f}'))

    # ---------------------------------------------------------- Panel E
    onset_h = hours(ex['sofa_time'], ex['icu_intime'])
    idx_h = ex[['alp_h_from_icu', 'alb_h_from_icu']].apply(
        pd.to_numeric, errors='coerce').max(axis=1)
    rel = (idx_h - onset_h).dropna()
    if len(rel):
        med, q1, q3, n = med_iqr(rel)
        rows.append(dict(Panel='E', Stratum='Overall (index draw minus sepsis onset)',
                         n=len(rel), pct='', Median=r2(med),
                         IQR=f'{q1:.2f}–{q3:.2f}'))
        for lab, c, p in binned(rel, [-np.inf, 0, 6, 12, 24, np.inf],
                                ['Drawn before sepsis onset (<0 h)', '0 to <6 h',
                                 '6 to <12 h', '12 to <24 h', '≥24 h']):
            rows.append(dict(Panel='E', Stratum=lab, n=int(c), pct=f'{p:.1f}%',
                             Median='', IQR=''))

    # Among the patients whose albumin was drawn after ALP, how many had that
    # albumin drawn after sepsis onset, and by how much?
    lag = pd.to_numeric(ex['alb_alp_lag_h'], errors='coerce')
    after = ex[lag > 1e-9]
    if len(after):
        alb_rel = (pd.to_numeric(after['alb_h_from_icu'], errors='coerce')
                   - hours(after['sofa_time'], after['icu_intime']))
        k = int((alb_rel > 0).sum())
        m_, q1_, q3_, _ = med_iqr(alb_rel[alb_rel > 0])
        rows.append(dict(Panel='E',
                         Stratum='Albumin drawn after ALP and after sepsis onset',
                         n=f'{k} of {len(after)}',
                         pct=f'{100 * k / len(after):.1f}%',
                         Median=round(m_, 2), IQR=f'{q1_:.2f}–{q3_:.2f}'))

    tab = pd.DataFrame(rows)
    tab.to_csv(f'{args.outdir}/TableS2_timing.csv', index=False, encoding='utf-8-sig')
    print(tab.to_string(index=False))
    print('\nWritten to', args.outdir)


if __name__ == '__main__':
    main()
