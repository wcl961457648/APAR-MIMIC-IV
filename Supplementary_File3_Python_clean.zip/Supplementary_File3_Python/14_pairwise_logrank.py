"""
Pairwise log-rank tests between APAR quartiles.

The Kaplan-Meier curves in Figure 3 separate only from the third quartile
onwards: the unadjusted cumulative mortality is 26.5 / 25.6 / 32.6 / 43.8 % at
30 days and 32.7 / 32.9 / 39.9 / 56.4 % at 90 days across Q1-Q4, so Q1 and Q2
are effectively superimposed and the unadjusted pattern is not monotone.  The
four-group log-rank test quoted in the manuscript (P < 0.001) says nothing about
where that separation starts, which is why every pair is tested here.

Output: results/Figure3_km_pairwise_logrank.csv
    Horizon, Comparison, n_A, n_B, Events_A, Events_B, Chi2, df, P_value

All six pairs per horizon are written, so the file also documents that the
adjacent comparisons Q1-Q2 are indistinguishable while Q2-Q3 and beyond carry
the gradient.  No multiplicity adjustment is applied: these tests describe the
shape of the unadjusted curves, and inference rests on the multivariable Cox
models.
"""
import os
from itertools import combinations

import pandas as pd
from lifelines.statistics import logrank_test

from apar_common import HORIZONS, common_args, load_cohort

QUARTILES = ['Q1', 'Q2', 'Q3', 'Q4']


def pairwise_logrank(m, horizons=HORIZONS):
    rows = []
    for hz, T, E, tau in horizons:
        d = m[[T, E, 'apar_q']].dropna()
        for q1, q2 in combinations(QUARTILES, 2):
            s1 = d[d['apar_q'] == q1]
            s2 = d[d['apar_q'] == q2]
            r = logrank_test(s1[T].astype(float), s2[T].astype(float),
                             event_observed_A=s1[E].astype(int),
                             event_observed_B=s2[E].astype(int))
            rows.append(dict(Horizon=hz, Comparison='%s vs %s' % (q1, q2),
                             n_A=len(s1), n_B=len(s2),
                             Events_A=int(s1[E].sum()), Events_B=int(s2[E].sum()),
                             Chi2=float(r.test_statistic), df=1,
                             P_value=float(r.p_value)))
    return pd.DataFrame(rows)


def main():
    args = common_args(__doc__).parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    m, _sc = load_cohort(args.cohort, args.derived)
    out = pairwise_logrank(m)
    path = os.path.join(args.outdir, 'Figure3_km_pairwise_logrank.csv')
    out.to_csv(path, index=False, encoding='utf-8-sig')
    print(out.to_string(index=False))
    print('\nOK: wrote', path)


if __name__ == '__main__':
    main()
