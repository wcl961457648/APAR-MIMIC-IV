"""
Figure 2 (restricted cubic splines, 30 and 90 days) and Figure 3 (Kaplan-Meier
curves by APAR quartile).  Each Kaplan-Meier panel is followed by a
number-at-risk table that shares its x axis, so the counts line up with the
time points of the curve.

Figure 1 (study flow diagram) is drawn from the counts returned by
sql/01_cohort_extraction.sql rather than from the analytic data set, and is not
reproduced here.

The spline uses 4 knots at the 5th, 35th, 65th and 95th percentiles of APAR,
adjusted for the Model 3 covariates, referenced at the median APAR.  The
non-linearity P value is from a likelihood-ratio test against a model in which
APAR enters linearly.
"""
import warnings

warnings.filterwarnings('ignore')

import os

import matplotlib

matplotlib.use('Agg')

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from lifelines import CoxPHFitter, KaplanMeierFitter
from scipy import stats

from apar_common import ADJ, HORIZONS, common_args, load_cohort, survival_frame

PENALIZER = 1e-6
GREY40, PRIMARY = '#666666', '#b2182b'
PALETTE = ['#2166ac', '#67a9cf', '#ef8a62', '#b2182b']


def rcs_basis(x, knots):
    x = np.asarray(x, float)
    t = np.sort(np.asarray(knots, float))
    K = len(t)
    denom = (t[-1] - t[0]) ** 2
    cols = [x]
    for k in range(K - 2):
        tk = t[k]
        num = (np.maximum(x - tk, 0) ** 3
               - np.maximum(x - t[-2], 0) ** 3 * (t[-1] - tk) / (t[-1] - t[-2])
               + np.maximum(x - t[-1], 0) ** 3 * (t[-2] - tk) / (t[-1] - t[-2]))
        cols.append(num / denom)
    return np.column_stack(cols)


def fit_rcs(m, T, E, pcts=(5, 35, 65, 95)):
    knots = np.percentile(m['apar'].dropna(), pcts)
    B = rcs_basis(m['apar'].values, knots)
    d = m.copy()
    rc = []
    for j in range(B.shape[1]):
        col = f'rcs_{j}'
        d[col] = B[:, j]
        rc.append(col)
    dd = survival_frame(d, rc + ADJ, T, E)
    dd_apar = d.loc[d[rc + ADJ + [T, E]].dropna().index, 'apar'].values
    cph = CoxPHFitter(penalizer=PENALIZER)
    cph.fit(dd, 'T', 'E', show_progress=False)
    dl = survival_frame(d, ADJ + ['apar'], T, E)
    cl = CoxPHFitter(penalizer=PENALIZER)
    cl.fit(dl, 'T', 'E', show_progress=False)
    # Likelihood-ratio test of the spline basis against a single linear term:
    # the chi-square statistic itself is written out next to the P value so the
    # test can be quoted in full (chi-square, df, P) rather than P alone.
    lr = max(2 * (cph.log_likelihood_ - cl.log_likelihood_), 0.0)
    df_nl = B.shape[1] - 1
    p_nl = 1 - stats.chi2.cdf(lr, df_nl)
    return cph, knots, float(p_nl), dd, dd_apar, rc, float(lr), int(df_nl)


def predict_rcs(cph, knots, dd, dd_apar, rc, n=200):
    grid = np.linspace(np.quantile(dd_apar, .01), np.quantile(dd_apar, .99), n)
    B = rcs_basis(grid, knots)
    Xp = pd.DataFrame({f'rcs_{j}': B[:, j] for j in range(B.shape[1])})
    for c in ADJ:
        Xp[c] = dd[c].median()
    ref = rcs_basis(np.array([np.median(dd_apar)]), knots)
    Xr = Xp.copy()
    for j, v in enumerate(ref[0]):
        Xr[f'rcs_{j}'] = v
    V = cph.variance_matrix_.values
    lhr = (cph.predict_log_partial_hazard(Xp).values
           - cph.predict_log_partial_hazard(Xr).values)
    vx = np.einsum('ij,jk,ik->i', Xp.values, V, Xp.values)
    vr = float(np.atleast_1d(np.einsum('ij,jk,ik->i', Xr.values, V, Xr.values))[0])
    # Variance of a *contrast* against the reference, not of a single point.
    # Var(log HR(x) - log HR(ref)) = Var(x) + Var(ref) - 2 Cov(x, ref).
    # Dropping the covariance term (the earlier `vx - vr`) makes the quantity
    # negative at every grid point here, and np.maximum(..., 0) then truncates
    # the standard error to zero, so fill_between() draws a band of zero width
    # and no confidence interval is visible on the figure.
    cov = np.einsum('ij,jk,ik->i', Xp.values, V, Xr.values)
    return grid, lhr, np.sqrt(np.maximum(vx + vr - 2 * cov, 0))


def figure_rcs(m, outdir):
    out = []
    # 180 mm native layout: the canvas is already the final 7.087 in wide and is
    # rendered at 300 dpi, so the point sizes used below are the point sizes that
    # appear in the printed figure (no down-sampling afterwards).
    fig, axes = plt.subplots(1, 2, figsize=(7.188, 2.811), dpi=300)
    for ax, (hz, T, E, _), ttl, lbl in zip(axes, HORIZONS, ['30-day', '90-day'],
                                           ['A', 'B']):
        cph, knots, p_nl, dd, dd_apar, rc, lr_chisq, df_nl = fit_rcs(m, T, E)
        grid, lhr, se = predict_rcs(cph, knots, dd, dd_apar, rc)
        hr, lo, hi = np.exp(lhr), np.exp(lhr - 1.96 * se), np.exp(lhr + 1.96 * se)
        ax.plot(grid, hr, color=PRIMARY, lw=2)
        ax.fill_between(grid, lo, hi, color=PRIMARY, alpha=.15, lw=0)
        ax.axhline(1, color=GREY40, lw=.8, ls='--')
        for k in knots:
            ax.axvline(k, color=GREY40, lw=.5, ls=':', alpha=.5)
        ax.scatter([np.median(dd_apar)], [1], color='white', edgecolor=PRIMARY, s=40, zorder=5)
        idx = np.random.default_rng(0).choice(len(dd_apar), size=min(200, len(dd_apar)),
                                              replace=False)
        # The rug is drawn only inside the fitted range (1st-99th percentile).
        # A handful of extreme APAR values reach 56.8, and drawing them set the
        # axis limits to 0-40 while the curve stops at about 25.7, leaving the
        # right third of the panel empty.  Points outside the window are dropped
        # rather than clipped, so no half-drawn tick is left at the edge.
        rug = dd_apar[idx]
        rug = rug[(rug >= grid[0]) & (rug <= grid[-1])]
        # The rug sits just above the lower spine.  It was previously drawn at
        # y = 0.97, i.e. within 0.03 units of the HR = 1 reference line, so at
        # print size it read as a ragged edge on the dashed line rather than as
        # a distribution.  At 0.46 it clears both the reference line and the
        # lowest point of the curve (about 0.72).
        ax.plot(rug, np.full(len(rug), .46), '|', color=GREY40, alpha=.4, ms=4)
        # At 180 mm each panel is only ~63 mm wide.  Both panels share the same
        # y quantity, so the label is printed once on the left panel; repeating
        # it on the right would leave the two axis labels almost touching.
        ax.set_xlabel('APAR\n(ALP, IU/L / albumin, g/L)', fontsize=9, labelpad=2)
        if lbl == 'A':
            ax.set_ylabel('Adjusted HR (95% CI)', fontsize=9, labelpad=2)
        else:
            ax.set_ylabel('')
        ax.set_title(f'{ttl} mortality')
        # Upper bound 3.1: the corrected 90-day confidence band peaks at
        # HR 3.06 near APAR 25.7, which the previous limit of 3.0 clipped.
        ax.set_ylim(.4, 3.1)
        # Lock the x axis to the fitted range.  Keep this in step with the rug
        # filter above: the window is the same 1st-99th percentile used to build
        # the prediction grid, so every knot and the reference marker stay
        # inside the axes.  The axis starts at 0 because APAR is a ratio and the
        # lower end of the curve would otherwise sit on the y axis; the upper
        # end gets a 2% pad so the curve does not run into the right spine.
        ax.set_xlim(0, grid[-1] * 1.02)
        # Panel letter in the top-left corner, level with the panel title.
        # The letter is drawn in axes coordinates so it sits outside the data
        # area and cannot collide with the P-value annotation at (.02, .98).
        ax.text(0.0, 1.02, lbl, transform=ax.transAxes, ha='left', va='bottom',
                fontsize=13, fontweight='bold', color='black')
        ax.text(.02, .98, f'P for non-linearity = {p_nl:.3f}', transform=ax.transAxes,
                va='top', ha='left', fontsize=9, color=GREY40)
        out.append(dict(Horizon=hz, LR_chi2=lr_chisq, df=df_nl,
                        P_nonlinearity=p_nl,
                        Knots=', '.join(f'{k:.2f}' for k in knots)))
    # No in-image figure title: the manuscript figure legend carries it.
    # w_pad widens the gutter between the two panels so that the tick labels and
    # the right panel's y label do not touch at 180 mm.
    fig.tight_layout(w_pad=2.4)
    for ext in ['png', 'pdf', 'tiff']:
        fig.savefig(f'{outdir}/Figure2_RCS.{ext}', dpi=300, bbox_inches='tight')
    plt.close(fig)
    return pd.DataFrame(out)


RISK_TICKS = {'30d': [0, 7, 14, 21, 30], '90d': [0, 15, 30, 60, 90]}


def figure_km(m, outdir):
    out = []
    # 180 mm native layout (see figure_rcs); rendered at 300 dpi, never resampled.
    fig = plt.figure(figsize=(8.208, 4.404), dpi=300)
    gs = fig.add_gridspec(2, 2, height_ratios=[3.5, 1.0], hspace=.14, wspace=.22)
    axes = [fig.add_subplot(gs[0, j]) for j in range(2)]
    # The bottom row is the number-at-risk table; it shares the x axis with the
    # curves above so the counts line up with the time points.
    risk_axes = [fig.add_subplot(gs[1, j], sharex=axes[j]) for j in range(2)]
    for ax, rax, (hz, T, E, tau), lbl in zip(axes, risk_axes, HORIZONS, ['A', 'B']):
        for i, q in enumerate(['Q1', 'Q2', 'Q3', 'Q4']):
            sub = m[m['apar_q'] == q]
            kmf = KaplanMeierFitter()
            kmf.fit(sub[T].astype(float), sub[E].astype(int), label=q)
            kmf.plot_survival_function(ax=ax, ci_show=False, color=PALETTE[i], lw=1.6)
            ci = kmf.confidence_interval_survival_function_
            t_ci = ci.index.values.astype(float)
            ax.fill_between(t_ci, ci.iloc[:, 0].values, ci.iloc[:, 1].values,
                            color=PALETTE[i], alpha=.12, lw=0)
            at_risk = int((sub[T] >= tau).sum())
            # Components of the risk set, so that a reader who reconstructs it
            # as n - events can reconcile the two: the set at time t holds the
            # patients with T >= t, which includes the deaths recorded on that
            # exact day (survival time is counted in whole days), and excludes
            # anyone censored earlier.  at_risk = n - events + deaths_at_tau
            # - censored_before_tau.
            t_km = sub[T].astype(float)
            e_km = sub[E].astype(int)
            deaths_at_tau = int(((e_km == 1) & (t_km == tau)).sum())
            cens_before = int(((e_km == 0) & (t_km < tau)).sum())
            out.append(dict(Horizon=hz, Quartile=q, n=len(sub), events=int(sub[E].sum()),
                            survival_at_tau=float(kmf.predict(tau)), at_risk_at_tau=at_risk,
                            deaths_at_tau=deaths_at_tau,
                            censored_before_tau=cens_before))
        # The x range is widened at both ends: 12% on the left for the row
        # labels of the risk table, 6% on the right so the count at tau is not
        # clipped.  Both rows share this range.
        ax.set_xlim(-.12 * tau, 1.06 * tau)
        ax.set_ylim(0, 1)
        ax.set_ylabel('Survival probability')
        ax.set_title(f'{hz.replace("d", "-day")} mortality')
        ax.legend(title='APAR quartile', loc='lower left', fontsize=8, title_fontsize=8)
        # Panel letter in the top-left corner, level with the panel title,
        # drawn in axes coordinates so it sits outside the data area.
        ax.text(0.0, 1.02, lbl, transform=ax.transAxes, ha='left', va='bottom',
                fontsize=13, fontweight='bold', color='black')
        ax.tick_params(bottom=False, labelbottom=False)

        # --- number at risk --------------------------------------------------
        ticks = RISK_TICKS[hz]
        rax.set_ylim(.4, 5.4)
        rax.set_yticks([])
        for s in ('top', 'right', 'left'):
            rax.spines[s].set_visible(False)
        rax.set_xticks(ticks)
        rax.set_xticklabels([str(t) for t in ticks], fontsize=8)
        rax.set_xlabel('Days since ICU admission', fontsize=9, labelpad=2)
        rax.text(-.12 * tau, 5.0, 'Number at risk', ha='left', va='center',
                 fontsize=8, color=GREY40)
        for j, q in enumerate(['Q1', 'Q2', 'Q3', 'Q4']):
            sub = m[m['apar_q'] == q]
            y = 4.0 - j
            rax.text(-.12 * tau, y, q, ha='left', va='center', fontsize=8, color=GREY40)
            for t in ticks:
                rax.text(t, y, f'{int((sub[T] >= t).sum())}',
                         ha='center', va='center', fontsize=8)
    # No in-image figure title: the manuscript figure legend carries it.
    fig.tight_layout()
    for ext in ['png', 'pdf', 'tiff']:
        fig.savefig(f'{outdir}/Figure3_KM.{ext}', dpi=300, bbox_inches='tight')
    plt.close(fig)
    return pd.DataFrame(out)


def main():
    args = common_args(__doc__).parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    m, sc = load_cohort(args.cohort, args.derived)
    rcs = figure_rcs(m, args.outdir)
    rcs.to_csv(f'{args.outdir}/Figure2_rcs_nonlinearity.csv', index=False, encoding='utf-8-sig')
    km = figure_km(m, args.outdir)
    km.to_csv(f'{args.outdir}/Figure3_km_summary.csv', index=False, encoding='utf-8-sig')

    print('===== Non-linearity tests =====')
    print(rcs.to_string(index=False))
    print('\n===== Kaplan-Meier summary =====')
    print(km.to_string(index=False))
    print('\nFigures 2 and 3 written to', args.outdir)


if __name__ == '__main__':
    main()
