"""
Restricted mean survival time (RMST) and time-varying checks behind
Supplementary Tables S7 and S8.

Because follow-up is administratively censored at each horizon and no patient
is censored before tau, RMST(tau) = mean[ min(T, tau) ]; the jackknife
pseudo-observation then reduces exactly to the individual restricted time
theta_i = min(T_i, tau).  Section 1 verifies that identity numerically.  Section 3
therefore uses an ordinary linear model on theta_i with HC3 robust standard
errors (this is what pseudo-observation regression with an identity link gives
in this special case).

Sections 4 and 5 implement Supplementary Table S8: interval-specific HRs from a
time-split (piecewise-exponential-style Cox) model and a time-varying
coefficient model APAR x log(t).

Section 6 repeats the interval-specific analysis of Section 4 on the per-1-SD
scale of APAR (the scale used for the main results) and records the number at
risk and the number of events in each interval.  It also reports the
event-weighted mean of the interval log HRs, which is what the single Cox HR
averages over, next to that single Cox HR.

Important detail shared by both: the log-time variable 'g' uses the *interval
midpoint* (a step function constant within each interval).  Using each row's own
stop time would leak the outcome into the predictor.
"""
import warnings

warnings.filterwarnings('ignore')

import os

import numpy as np
import pandas as pd
from lifelines import CoxPHFitter, CoxTimeVaryingFitter, KaplanMeierFitter
from scipy import stats

from apar_common import ADJ, HORIZONS, common_args, load_cohort

PENALIZER = 1e-6


# ---------------------------------------------------------------- helpers
def rmst_km(t, e, tau):
    """RMST = integral of S(u) from 0 to tau, integrating the KM step function."""
    kmf = KaplanMeierFitter().fit(t.astype(float), e.astype(int))
    times = np.asarray(kmf.survival_function_.index, dtype=float)
    s = np.asarray(kmf.survival_function_.values, dtype=float).flatten()
    keep = times < tau
    tt = np.concatenate([times[keep], [tau]])
    return float(np.sum(s[keep] * np.diff(tt)))


def hc3_ols(X, y):
    """OLS with HC3 heteroskedasticity-robust covariance (X includes intercept)."""
    X = np.asarray(X, float)
    y = np.asarray(y, float)
    XtX_inv = np.linalg.pinv(X.T @ X)
    b = XtX_inv @ X.T @ y
    res = y - X @ b
    H = X @ XtX_inv @ X.T
    h = np.clip(np.diag(H), 0, 1 - 1e-12)
    w = (res ** 2) / ((1 - h) ** 2)
    V = XtX_inv @ (X.T @ (X * w[:, None])) @ XtX_inv
    se = np.sqrt(np.diag(V))
    z = b / se
    p = 2 * (1 - stats.norm.cdf(np.abs(z)))
    return b, se, p


def design(df, cols):
    return np.column_stack([np.ones(len(df))] + [df[c].astype(float).values for c in cols])


def to_long(df, cuts):
    """Expand a survival frame into (start, stop, event) rows over `cuts`."""
    out = []
    tt, ee = df['T'].astype(float), df['E'].astype(int)
    for k in range(len(cuts) - 1):
        a, b = cuts[k], cuts[k + 1]
        sel = tt > a
        sub = df.loc[sel].copy()
        sub = sub.assign(start=max(a, 0.0),
                         stop=np.minimum(tt[sel].values, b),
                         ev=np.where(tt[sel].values <= b, ee[sel].values, 0),
                         interval=k,
                         g=np.log((a + b) / 2.0))
        out.append(sub)
    return pd.concat(out, ignore_index=True)


def main():
    args = common_args(__doc__).parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    m, sc = load_cohort(args.cohort, args.derived)
    SD = sc['SD_apar']
    m['apar_z'] = m['apar'] / SD          # APAR per 1 SD
    print(f"N = {sc['N']} | SD(APAR) = {SD:.3f}")

    # ------------------------------ 1. pseudo-observation identity check
    print('\n===== 1. pseudo-observation identity check =====')
    for hz, T, E, tau in HORIZONS:
        t, e = m[T].astype(float), m[E].astype(int)
        x = np.minimum(t.values, tau)
        full = rmst_km(t, e, tau)
        rng = np.random.default_rng(11)
        idx = rng.choice(len(m), 200, replace=False)
        maxdev = 0.0
        for i in idx:
            lo = rmst_km(t.drop(t.index[i]), e.drop(e.index[i]), tau)
            theta_i = len(m) * full - (len(m) - 1) * lo
            maxdev = max(maxdev, abs(theta_i - x[i]))
        print(f'  {hz}: RMST(all) = {full:.4f} | mean[min(T,tau)] = {x.mean():.4f} | '
              f'max |theta_i - min(T_i,tau)| over 200 draws = {maxdev:.2e}')

    # ------------------------------ 2. RMST by quartile (Table S7, unadjusted)
    rmst_rows, diff_rows = [], []
    for hz, T, E, tau in HORIZONS:
        x = np.minimum(m[T].astype(float).values, tau)
        m['_x'] = x
        for q in ['Q1', 'Q2', 'Q3', 'Q4']:
            xs = m.loc[m.apar_q == q, '_x'].values
            mean, sd = xs.mean(), xs.std(ddof=1)
            rmst_rows.append(dict(Horizon=hz, tau=tau, Quartile=q, n=len(xs),
                                  RMST_days=round(float(mean), 2), SD=round(float(sd), 2),
                                  CI_lo=round(float(mean - 1.96 * sd / np.sqrt(len(xs))), 2),
                                  CI_hi=round(float(mean + 1.96 * sd / np.sqrt(len(xs))), 2)))
        x1 = m.loc[m.apar_q == 'Q1', '_x'].values
        x4 = m.loc[m.apar_q == 'Q4', '_x'].values
        diff = x4.mean() - x1.mean()
        se = np.sqrt(x1.var(ddof=1) / len(x1) + x4.var(ddof=1) / len(x4))
        p = float(stats.ttest_ind(x4, x1, equal_var=False).pvalue)
        diff_rows.append(dict(Horizon=hz, tau=tau, Contrast='Q4 vs Q1',
                              diff_days=round(float(diff), 2),
                              lo=round(float(diff - 1.96 * se), 2),
                              hi=round(float(diff + 1.96 * se), 2), P=p))
    pd.DataFrame(rmst_rows).to_csv(f'{args.outdir}/TableS7_rmst_by_quartile.csv',
                                   index=False, encoding='utf-8-sig')
    pd.DataFrame(diff_rows).to_csv(f'{args.outdir}/TableS7_rmst_unadjusted_diff.csv',
                                   index=False, encoding='utf-8-sig')

    # ------------------------------ 3. adjusted RMST difference
    adj_rows = []
    for hz, T, E, tau in HORIZONS:
        d = m.copy()
        d['theta'] = np.minimum(d[T].astype(float).values, tau)
        d = pd.concat([d, pd.get_dummies(d['apar_q'], prefix='aq', drop_first=True).astype(float)],
                      axis=1)
        cols = ['aq_Q2', 'aq_Q3', 'aq_Q4'] + ADJ
        dd = d[cols + ['theta']].dropna()
        b, se, p = hc3_ols(design(dd, cols), dd['theta'].values)
        for j, c in enumerate(cols, start=1):
            adj_rows.append(dict(Horizon=hz, tau=tau, term=c, beta=round(float(b[j]), 3),
                                 SE=round(float(se[j]), 3),
                                 lo=round(float(b[j] - 1.96 * se[j]), 2),
                                 hi=round(float(b[j] + 1.96 * se[j]), 2), P=float(p[j])))
    pd.DataFrame(adj_rows).to_csv(f'{args.outdir}/TableS7_rmst_adjusted.csv',
                                  index=False, encoding='utf-8-sig')

    # ------------------------------ 4. time-split HRs (Table S8)
    splits = {'30d': [0, 7, 30], '90d': [0, 7, 30, 90]}
    split_rows, split_tests = [], []
    for hz, T, E, tau in HORIZONS:
        cuts = splits[hz]
        base = m[ADJ + ['apar_q', 'apar_z', T, E]].dropna().copy()
        base['T'], base['E'] = base[T], base[E]
        long = to_long(base.drop(columns=[T, E]), cuts)
        long = pd.concat([long, pd.get_dummies(long['apar_q'], prefix='aq',
                                               drop_first=True).astype(float)], axis=1)
        idf = pd.get_dummies(long['interval'], prefix='iv').astype(float).drop(columns=['iv_0'])
        long = pd.concat([long, idf], axis=1)
        ivcols = list(idf.columns)
        for q in ['aq_Q2', 'aq_Q3', 'aq_Q4']:
            for c in ivcols:
                long[f'{q}:{c}'] = long[q] * long[c]
        inter = [f'{q}:{c}' for q in ['aq_Q2', 'aq_Q3', 'aq_Q4'] for c in ivcols]
        core = ['aq_Q2', 'aq_Q3', 'aq_Q4'] + ADJ + ivcols

        def ctv(cols_):
            f = CoxTimeVaryingFitter(penalizer=PENALIZER)
            f.fit(long[['start', 'stop', 'ev'] + cols_].assign(id=np.arange(len(long))),
                  id_col='id', start_col='start', stop_col='stop', event_col='ev',
                  show_progress=False)
            return f

        f_red, f_full = ctv(core), ctv(core + inter)
        lr = 2 * (f_full.log_likelihood_ - f_red.log_likelihood_)
        split_tests.append(dict(Horizon=hz, test='quartile x interval (LR)',
                                LR=round(float(lr), 2), df=len(inter),
                                P=float(stats.chi2.sf(lr, len(inter)))))
        names = list(f_full.params_.index)
        V = np.asarray(f_full.variance_matrix_, dtype=float)
        i_q4 = names.index('aq_Q4')

        def lincomb(i1, i2=None):
            bb = float(f_full.params_.iloc[i1])
            v = V[i1, i1]
            if i2 is not None:
                bb += float(f_full.params_.iloc[i2])
                v = V[i1, i1] + V[i2, i2] + 2 * V[i1, i2]
            return bb, np.sqrt(max(v, 0.0)), np.sqrt(V[i1, i1])

        for k, iv in enumerate(['iv_0'] + ivcols):
            if iv == 'iv_0':
                b, se, _ = lincomb(i_q4)
            else:
                b, se, _ = lincomb(i_q4, names.index(f'aq_Q4:{iv}'))
            split_rows.append(dict(Horizon=hz, interval=f'[{cuts[k]}, {cuts[k + 1]})',
                                   term='Q4 vs Q1', HR=round(float(np.exp(b)), 3),
                                   lo=round(float(np.exp(b - 1.96 * se)), 3),
                                   hi=round(float(np.exp(b + 1.96 * se)), 3),
                                   P=float(2 * (1 - stats.norm.cdf(abs(b / se))))))
    pd.DataFrame(split_rows).to_csv(f'{args.outdir}/TableS8_timesplit_hrs.csv',
                                    index=False, encoding='utf-8-sig')
    pd.DataFrame(split_tests).to_csv(f'{args.outdir}/TableS8_timesplit_tests.csv',
                                     index=False, encoding='utf-8-sig')

    # ------------------------------ 5. time-varying coefficient model
    tvc_cuts = {'30d': [0, 3, 7, 14, 30], '90d': [0, 3, 7, 14, 30, 60, 90]}
    tv_rows, tv_tests = [], []
    for hz, T, E, tau in HORIZONS:
        cuts = tvc_cuts[hz]
        base = m[ADJ + ['apar_z', T, E]].dropna().copy()
        base['T'], base['E'] = base[T], base[E]
        long = to_long(base.drop(columns=[T, E]), cuts)
        long['apar_z:g'] = long['apar_z'] * long['g']
        cols = ['apar_z', 'g', 'apar_z:g'] + ADJ
        f = CoxTimeVaryingFitter(penalizer=PENALIZER)
        f.fit(long[['start', 'stop', 'ev'] + cols].assign(id=np.arange(len(long))),
              id_col='id', start_col='start', stop_col='stop', event_col='ev',
              show_progress=False)
        b1, b2 = f.params_['apar_z'], f.params_['apar_z:g']
        p_int = float(f.summary.loc['apar_z:g', 'p'])
        print(f'\n  {hz} TVC: beta(APAR/SD at g=0) = {b1:.4f}, '
              f'beta(APAR x log t) = {b2:.4f}, P_interaction = {p_int:.3f}')
        # The interaction P is reported in the Table S8 footnote, so it is
        # written out as well instead of being left in the console log only.
        tv_tests.append(dict(Horizon=hz, test='APAR x log(time) (Wald)',
                             beta=round(float(b2), 4), P=round(p_int, 3)))
        Vt = np.asarray(f.variance_matrix_, dtype=float)
        nm = list(f.params_.index)
        ia, ii = nm.index('apar_z'), nm.index('apar_z:g')
        for tv in ([1, 7, 30] if hz == '30d' else [1, 7, 30, 90]):
            g = np.log(tv)
            hr = np.exp(b1 + b2 * g)
            v = Vt[ia, ia] + (g ** 2) * Vt[ii, ii] + 2 * g * Vt[ia, ii]
            se = np.sqrt(max(v, 0))
            tv_rows.append(dict(Horizon=hz, t_days=tv, HR_perSD=round(float(hr), 3),
                                lo=round(float(np.exp(b1 + b2 * g - 1.96 * se)), 3),
                                hi=round(float(np.exp(b1 + b2 * g + 1.96 * se)), 3)))
    pd.DataFrame(tv_rows).to_csv(f'{args.outdir}/TableS8_tvc_hrs.csv',
                                 index=False, encoding='utf-8-sig')
    pd.DataFrame(tv_tests).to_csv(f'{args.outdir}/TableS8_tvc_tests.csv',
                                  index=False, encoding='utf-8-sig')

    # ------------- 6. interval-specific HRs per 1 SD (Table S8, second block)
    # The single Cox HR is a weighted average of the interval-specific effects,
    # so the interval HRs are also reported on the per-1-SD scale (the scale on
    # which the main results are given) together with the number at risk and
    # the number of events inside each interval.
    per_rows, per_tests = [], []
    for hz, T, E, tau in HORIZONS:
        cuts = splits[hz]
        base = m[ADJ + ['apar_z', T, E]].dropna().copy()
        base['T'], base['E'] = base[T], base[E]
        long = to_long(base.drop(columns=[T, E]), cuts)
        idf = pd.get_dummies(long['interval'], prefix='iv').astype(float).drop(columns=['iv_0'])
        long = pd.concat([long, idf], axis=1)
        ivcols = list(idf.columns)
        for c in ivcols:
            long[f'z:{c}'] = long['apar_z'] * long[c]
        zinter = [f'z:{c}' for c in ivcols]

        def fitp(cols_):
            f = CoxTimeVaryingFitter(penalizer=PENALIZER)
            f.fit(long[['start', 'stop', 'ev'] + cols_].assign(id=np.arange(len(long))),
                  id_col='id', start_col='start', stop_col='stop', event_col='ev',
                  show_progress=False)
            return f

        pc = ['apar_z'] + ADJ + ivcols
        f_red, f_full = fitp(pc), fitp(pc + zinter)
        lr = 2 * (f_full.log_likelihood_ - f_red.log_likelihood_)
        per_tests.append(dict(Horizon=hz, test='APAR/SD x interval (LR)',
                              LR=round(float(lr), 2), df=len(zinter),
                              P=float(stats.chi2.sf(lr, len(zinter)))))
        nm = list(f_full.params_.index)
        Vp = np.asarray(f_full.variance_matrix_, dtype=float)
        iz = nm.index('apar_z')
        for k, iv in enumerate(['iv_0'] + ivcols):
            a, b = cuts[k], cuts[k + 1]
            if iv == 'iv_0':
                bb = float(f_full.params_.iloc[iz])
                v = Vp[iz, iz]
            else:
                j = nm.index(f'z:{iv}')
                bb = float(f_full.params_.iloc[iz]) + float(f_full.params_.iloc[j])
                v = Vp[iz, iz] + Vp[j, j] + 2 * Vp[iz, j]
            se = float(np.sqrt(max(v, 0.0)))
            natrisk = int((base['T'] > a).sum())
            nev = int(((base['T'] > a) & (base['T'] <= b) & (base['E'] == 1)).sum())
            per_rows.append(dict(Horizon=hz, interval=f'[{a}, {b})',
                                 term='APAR per 1 SD',
                                 HR=round(float(np.exp(bb)), 3),
                                 lo=round(float(np.exp(bb - 1.96 * se)), 3),
                                 hi=round(float(np.exp(bb + 1.96 * se)), 3),
                                 P=float(2 * (1 - stats.norm.cdf(abs(bb / se)))),
                                 n_at_risk=natrisk, n_events=nev))
        # single (time-fixed) Cox HR per 1 SD on the same patients
        cf = CoxPHFitter(penalizer=PENALIZER)
        cf.fit(base[['T', 'E'] + ['apar_z'] + ADJ], 'T', 'E')
        bsc = float(cf.params_['apar_z'])
        sesc = float(cf.standard_errors_['apar_z'])
        # Event-weighted mean of the interval log HRs.  The interval estimates
        # share the main APAR coefficient and are therefore correlated, so the
        # variance is obtained from the full covariance matrix of the interval
        # log hazard ratios (delta method) rather than from their separate SEs.
        sub = [r for r in per_rows if r['Horizon'] == hz and r['term'] == 'APAR per 1 SD']
        nk = len(cuts) - 1
        jk = [None] + [nm.index(f'z:{c}') for c in ivcols]

        def cov_lb(k, l):
            ik, il = jk[k], jk[l]
            v = Vp[iz, iz]
            if ik is not None:
                v += Vp[ik, iz]
            if il is not None:
                v += Vp[iz, il]
            if ik is not None and il is not None:
                v += Vp[ik, il]
            return v

        C = np.array([[cov_lb(k, l) for l in range(nk)] for k in range(nk)], float)
        w = np.array([r['n_events'] for r in sub], float)
        lb = np.array([np.log(r['HR']) for r in sub])
        aw = float((lb * w).sum() / w.sum())
        sew = float(np.sqrt(max(float(w @ C @ w) / (w.sum() ** 2), 0.0)))
        for tag, bb, se in [('event-weighted mean of interval log HRs', aw, sew),
                            ('single Cox model (time-fixed)', bsc, sesc)]:
            per_rows.append(dict(Horizon=hz, interval=f'[0, {tau})', term=tag,
                                 HR=round(float(np.exp(bb)), 3),
                                 lo=round(float(np.exp(bb - 1.96 * se)), 3),
                                 hi=round(float(np.exp(bb + 1.96 * se)), 3),
                                 P=float(2 * (1 - stats.norm.cdf(abs(bb / se)))),
                                 n_at_risk=len(base),
                                 n_events=int(base['E'].sum())))
    pd.DataFrame(per_rows).to_csv(f'{args.outdir}/TableS8_period_hrs.csv',
                                  index=False, encoding='utf-8-sig')
    pd.DataFrame(per_tests).to_csv(f'{args.outdir}/TableS8_period_tests.csv',
                                   index=False, encoding='utf-8-sig')

    pd.set_option('display.width', 200)
    print('\n===== RMST by quartile =====')
    print(pd.DataFrame(rmst_rows).to_string(index=False))
    print('\n===== RMST difference Q4 - Q1 (unadjusted) =====')
    print(pd.DataFrame(diff_rows).to_string(index=False))
    print('\n===== Interval-specific HRs (Q4 vs Q1) =====')
    print(pd.DataFrame(split_rows).to_string(index=False))
    print('\n===== HR per 1-SD from the time-varying coefficient model =====')
    print(pd.DataFrame(tv_rows).to_string(index=False))
    print('\n===== Interval-specific HRs per 1 SD =====')
    print(pd.DataFrame(per_rows).to_string(index=False))
    print('\nOutputs written to', args.outdir)


if __name__ == '__main__':
    main()
