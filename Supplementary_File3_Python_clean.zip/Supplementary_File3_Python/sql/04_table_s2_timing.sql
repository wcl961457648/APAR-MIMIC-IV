/* ============================================================================
   TABLE S2 - TIMING OF THE INDEX ALP AND ALBUMIN MEASUREMENTS
   ----------------------------------------------------------------------------
   Because ALP and albumin are each allowed to contribute their own FIRST value
   inside the 24 h window, the two draws are not necessarily simultaneous.
   The distribution of the sampling times is reported in Supplementary Table S2
   and is reproduced here.

   Reported values (N = 1,865):
     * time from ICU admission to the index ALP draw
         median 1.80 h (IQR 0.61 - 6.18)
     * time from ICU admission to the index albumin draw
         median 2.38 h (IQR 0.69 - 7.97)
     * both analytes drawn at the same time (identical charttime)
         1,645 patients (88.2%)
     * albumin drawn later than ALP
         220 patients (11.8%), median delay 9.76 h
   ============================================================================ */

SET search_path TO mimiciv_hosp, mimiciv_icu, mimiciv_derived, public;

/* ----------------------------------------------------------------------------
   Times of the two index draws, in hours after ICU admission
   ---------------------------------------------------------------------------- */
DROP TABLE IF EXISTS tmp_draw_times;
CREATE TEMP TABLE tmp_draw_times AS
WITH w AS (
    SELECT c.stay_id,
           ic.intime,
           ic.intime + INTERVAL '24 hours' AS t24
    FROM apar_cohort_1865 c
    JOIN mimiciv_icu.icustays ic USING (stay_id)
),
l AS (
    SELECT w.stay_id,
           le.itemid,
           le.charttime,
           EXTRACT(EPOCH FROM (le.charttime - w.intime)) / 3600.0 AS hours_from_icu,
           ROW_NUMBER() OVER (PARTITION BY w.stay_id, le.itemid
                              ORDER BY le.charttime, le.labevent_id) AS rn
    FROM w
    JOIN mimiciv_icu.icustays ic ON ic.stay_id = w.stay_id
    JOIN mimiciv_hosp.labevents le
      ON le.hadm_id = ic.hadm_id
     AND le.itemid IN (50862, 50863)          -- 50862 albumin, 50863 ALP
     AND le.valuenum IS NOT NULL
     AND le.charttime >= w.intime
     AND le.charttime <  w.t24
)
SELECT stay_id,
       MAX(CASE WHEN itemid = 50863 AND rn = 1 THEN hours_from_icu END) AS alp_h_from_icu,
       MAX(CASE WHEN itemid = 50862 AND rn = 1 THEN hours_from_icu END) AS alb_h_from_icu
FROM l
GROUP BY stay_id;

/* ----------------------------------------------------------------------------
   Table S2, Panel B - distribution of the two sampling times
   ---------------------------------------------------------------------------- */
SELECT ROUND(PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY alp_h_from_icu)::numeric, 2) AS alp_q1,
       ROUND(PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY alp_h_from_icu)::numeric, 2) AS alp_median,
       ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY alp_h_from_icu)::numeric, 2) AS alp_q3,
       ROUND(PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY alb_h_from_icu)::numeric, 2) AS alb_q1,
       ROUND(PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY alb_h_from_icu)::numeric, 2) AS alb_median,
       ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY alb_h_from_icu)::numeric, 2) AS alb_q3
FROM tmp_draw_times;
-- expected: 0.61 / 1.80 / 6.18   and   0.69 / 2.38 / 7.97

/* ----------------------------------------------------------------------------
   Table S2, Panel C - were the two analytes drawn at the same time?
   ---------------------------------------------------------------------------- */
SELECT COUNT(*) FILTER (WHERE alp_h_from_icu = alb_h_from_icu)                    AS n_same_draw,
       ROUND(100.0 * COUNT(*) FILTER (WHERE alp_h_from_icu = alb_h_from_icu)
             / COUNT(*), 1)                                                        AS pct_same_draw,
       COUNT(*) FILTER (WHERE alb_h_from_icu > alp_h_from_icu)                     AS n_albumin_later,
       ROUND(PERCENTILE_CONT(0.50) WITHIN GROUP (
             ORDER BY alb_h_from_icu - alp_h_from_icu)
             FILTER (WHERE alb_h_from_icu > alp_h_from_icu)::numeric, 2)           AS median_delay_h
FROM tmp_draw_times;
-- expected: 1,645 / 88.2 / 220 / 9.76

/* ----------------------------------------------------------------------------
   Table S2, Panel A - time from ICU admission to sepsis onset
   and Panel D - vasopressor start relative to the index ALP draw.
   Both are read straight off the analytic table by 10_timing.py; the query is
   given here for completeness.
   ---------------------------------------------------------------------------- */
SELECT ROUND(PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY hours_icu_to_sepsis_onset)::numeric, 2) AS onset_q1,
       ROUND(PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY hours_icu_to_sepsis_onset)::numeric, 2) AS onset_median,
       ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY hours_icu_to_sepsis_onset)::numeric, 2) AS onset_q3
FROM apar_cohort_1865;

/* ============================================================================
   END OF FILE
   ============================================================================ */
