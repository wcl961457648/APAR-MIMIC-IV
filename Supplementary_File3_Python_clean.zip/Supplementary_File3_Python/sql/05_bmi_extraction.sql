/* ============================================================================
   BODY MASS INDEX FOR THE MISSINGNESS TABLE  (Supplementary Table S1)
   ----------------------------------------------------------------------------
   Manuscript : "Association of the alkaline phosphatase-to-albumin ratio with
                 30- and 90-day all-cause mortality in critically ill patients
                 with cirrhosis and sepsis"
   Target     : one BMI value per stay_id for the analytic cohort (N = 1,865)
   Database   : MIMIC-IV v3.1 (PhysioNet), PostgreSQL
   Requires   : mimiciv_hosp.apar_cohort_1865  (built by 01_cohort_extraction.sql)

   WHY THIS FILE EXISTS
   --------------------
   Body mass index is one of the ten candidate variables flagged in Methods
   section 2.5 as "missing in >15% of patients" and therefore excluded from
   every model.  Supplementary Table S1 has to report how many patients had a
   BMI, so the number must be reproducible.  Height and weight are not part of
   the laboratory extract (`cohort_v2_raw.csv`), which is why BMI is derived
   here in a separate, self-contained query.

   DEFINITION
   ----------
   BMI (kg/m2) = weight (kg) / (height (m))^2, both taken from the
   MIMIC-IV *derived* tables for the FIRST DAY of the index ICU stay:

     height  <- mimiciv_derived.first_day_height.height      (cm)
     weight  <- mimiciv_derived.first_day_weight.weight      (kg)

   The first-day window is the same 0-24 h window already used for the exposure
   and every other baseline covariate in the manuscript, so BMI is measured on
   the same footing as the rest of Table S1.  Values are set to NULL when they
   fall outside a physiologically plausible range (height 100-250 cm,
   weight 25-300 kg, BMI 10-80 kg/m2); a patient with no height or no weight
   in the window has no BMI.

   OUTPUT
   ------
   `apar_bmi_1865` : one row per stay_id (1,865 rows, bmi NULL when unavailable)
   Export to CSV and drop the file into `data/` as `bmi.csv`:

     \copy (SELECT stay_id, bmi FROM mimiciv_hosp.apar_bmi_1865 ORDER BY stay_id) TO 'data/bmi.csv' CSV HEADER

   `09_missingness.py` merges it on stay_id before counting missingness.
   ============================================================================ */

DROP VIEW IF EXISTS mimiciv_hosp.apar_bmi_1865;
CREATE VIEW mimiciv_hosp.apar_bmi_1865 AS
WITH coh AS (
    SELECT stay_id
    FROM mimiciv_hosp.apar_cohort_1865
),
h AS (
    -- first ICU day height, cm; implausible values discarded
    SELECT c.stay_id,
           MAX(CASE WHEN f.height BETWEEN 100 AND 250 THEN f.height END) AS height_cm
    FROM coh c
    LEFT JOIN mimiciv_derived.first_day_height f ON f.stay_id = c.stay_id
    GROUP BY c.stay_id
),
w AS (
    -- first ICU day weight, kg; implausible values discarded
    SELECT c.stay_id,
           MAX(CASE WHEN f.weight BETWEEN 25 AND 300 THEN f.weight END) AS weight_kg
    FROM coh c
    LEFT JOIN mimiciv_derived.first_day_weight f ON f.stay_id = c.stay_id
    GROUP BY c.stay_id
)
SELECT coh.stay_id,
       h.height_cm,
       w.weight_kg,
       CASE WHEN h.height_cm IS NOT NULL AND w.weight_kg IS NOT NULL
                 AND (w.weight_kg / (h.height_cm / 100.0) ^ 2) BETWEEN 10 AND 80
            THEN ROUND((w.weight_kg / (h.height_cm / 100.0) ^ 2)::numeric, 2)
       END AS bmi
FROM coh
LEFT JOIN h ON h.stay_id = coh.stay_id
LEFT JOIN w ON w.stay_id = coh.stay_id;

-- ---------------------------------------------------------------------------
-- Verification: must read 1,865 rows; the counts below are what Table S1
-- reports for the "Body mass index" row.
-- ---------------------------------------------------------------------------
SELECT COUNT(*)                                    AS n_rows,
       COUNT(bmi)                                  AS n_observed,
       COUNT(*) - COUNT(bmi)                       AS n_missing,
       ROUND((COUNT(*) - COUNT(bmi)) * 100.0 / COUNT(*), 1) AS pct_missing,
       ROUND(MIN(bmi)::numeric, 1)                 AS bmi_min,
       ROUND(AVG(bmi)::numeric, 1)                 AS bmi_mean,
       ROUND(MAX(bmi)::numeric, 1)                 AS bmi_max
FROM mimiciv_hosp.apar_bmi_1865;
