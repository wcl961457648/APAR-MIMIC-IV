/* ============================================================================
   AUXILIARY EXTRACTS FOR TABLE S5  (24-hour cohort, N = 1,865)
   ----------------------------------------------------------------------------
   Run AFTER 01_cohort_extraction.sql, which creates the table
   `apar_cohort_1865`.  Each block below writes one CSV:

     BLOCK 1  cc_stay.csv              complete cases for Model 3   (n = 1,831)
     BLOCK 2  albumin_before_draw.csv  albumin infused before the index draw
                                       (167 patients -> Table S5 row 5)
     BLOCK 3  anchor_year_group.csv    MIMIC-IV anchor-year group
                                       (-> Table S5 row 9, admissions from 2020)
     BLOCK 4  biliary.csv              coded biliary obstruction / cholangitis
                                       (152 patients -> Table S5 row 6)
     BLOCK 5  dsofa_cohort.csv         baseline-corrected SOFA rise
                                       (-> Table S5 row 7)

   Export with psql:
     psql -d mimic -f 03_sensitivity_cohorts.sql
     \copy (SELECT * FROM tmp_cc)      TO 'cc_stay.csv' CSV HEADER;
   ============================================================================ */

SET search_path TO mimiciv_hosp, mimiciv_icu, mimiciv_derived, public;

/* ----------------------------------------------------------------------------
   BLOCK 1 - complete cases for Model 3
   Model 3 covariates: age, gender, MELD-Na, SOFA, alcohol-related aetiology,
   AKI, ACLF (plus APAR).  A patient is a complete case when none of these is
   NULL and the 30-day outcome is defined.
   ---------------------------------------------------------------------------- */
DROP TABLE IF EXISTS tmp_cc;
CREATE TEMP TABLE tmp_cc AS
SELECT stay_id, 1 AS cc
FROM apar_cohort_1865
WHERE age IS NOT NULL
  AND gender IS NOT NULL
  AND meld_na IS NOT NULL
  AND sofa IS NOT NULL
  AND alcohol_flag IS NOT NULL
  AND aki IS NOT NULL
  AND aclf_binary IS NOT NULL
  AND apar IS NOT NULL
  AND death_30d IS NOT NULL;
-- expected: 1,831 of 1,865
SELECT COUNT(*) AS n_complete_cases FROM tmp_cc;


/* ----------------------------------------------------------------------------
   BLOCK 2 - albumin infusion started before the index draw
   Albumin itemids in mimiciv_icu.inputevents: 220574, 220861, 220862, 220863,
   220864, 227456.  "Before the index draw" = infusion starttime earlier than
   the charttime of the albumin measurement used to compute APAR.
   ---------------------------------------------------------------------------- */
DROP TABLE IF EXISTS tmp_albumin;
CREATE TEMP TABLE tmp_albumin AS
SELECT c.stay_id,
       (MIN(ie.starttime) < c.albumin_time) AS before
FROM apar_cohort_1865 c
LEFT JOIN mimiciv_icu.inputevents ie
  ON ie.stay_id = c.stay_id
 AND ie.itemid IN (220574, 220861, 220862, 220863, 220864, 227456)
 AND ie.amount > 0
 AND ie.starttime IS NOT NULL
GROUP BY c.stay_id, c.albumin_time;
-- expected: 167 patients with an albumin infusion before the index draw
SELECT COUNT(*) FILTER (WHERE before) AS n_albumin_before_draw FROM tmp_albumin;


/* ----------------------------------------------------------------------------
   BLOCK 3 - calendar period (MIMIC-IV anchor year group)
   Table S5 row 9 repeats the primary analysis after excluding admissions
   whose anchor_year_group is 2020 or later.
   ---------------------------------------------------------------------------- */
DROP TABLE IF EXISTS tmp_anchor;
CREATE TEMP TABLE tmp_anchor AS
SELECT DISTINCT c.subject_id, p.anchor_year_group
FROM apar_cohort_1865 c
JOIN mimiciv_hosp.patients p ON p.subject_id = c.subject_id;
SELECT anchor_year_group, COUNT(*) FROM tmp_anchor GROUP BY 1 ORDER BY 1;


/* ----------------------------------------------------------------------------
   BLOCK 4 - biliary obstruction / cholangitis
   ICD-9  : 5761 (cholangitis), 5762 (obstruction of bile duct),
            5740-5749, 5750 (calculus of gallbladder / bile duct)
   ICD-10 : K80*, K81*, K830*, K831*
   Any diagnosis position of the index admission.
   ---------------------------------------------------------------------------- */
DROP TABLE IF EXISTS tmp_biliary;
CREATE TEMP TABLE tmp_biliary AS
SELECT c.stay_id, 1 AS biliary_obs
FROM apar_cohort_1865 c
WHERE c.hadm_id IN (
    SELECT d.hadm_id FROM mimiciv_hosp.diagnoses_icd d
    WHERE (d.icd_version = 9  AND REPLACE(d.icd_code, '.', '') IN
              ('5761','5762','5740','5741','5742','5743','5744','5745',
               '5746','5747','5748','5749','5750'))
       OR (d.icd_version = 10 AND UPPER(REPLACE(d.icd_code, '.', '')) LIKE ANY
              (ARRAY['K830%','K831%','K80%','K81%']))
);
-- expected: 152 patients
SELECT COUNT(*) AS n_biliary FROM tmp_biliary;


/* ----------------------------------------------------------------------------
   BLOCK 5 - baseline-corrected SOFA (Table S5 row 7)
   baseline SOFA = the lowest SOFA recorded in the 48 h that precede the time
   of suspected infection (mimiciv_derived.sofa.sofa_24hours);
   SOFA at onset  = the sofa_24hours row closest in time to
                    mimiciv_derived.sepsis3.sofa_time;
   dSOFA          = SOFA at onset - baseline SOFA.
   Sensitivity analysis 7 (numbers below, and the labels written by
   07_sensitivity.py, follow Supplementary Table S5 exactly)
   excludes a patient only when a baseline SOFA IS available and the rise
   is < 2 (patients without a computable baseline are kept, because they
   cannot be shown to have failed the criterion):
   381 patients are excluded, leaving 1,484 (1,459 complete cases).
   The 1,102 patients with no computable baseline are NOT excluded; they
   are structurally missing rather than unmeasured, because suspected
   infection preceded ICU admission in every one of them.
   ---------------------------------------------------------------------------- */
DROP TABLE IF EXISTS tmp_dsofa;
CREATE TEMP TABLE tmp_dsofa AS
SELECT c.stay_id,
       s3.sofa_onset,
       b.baseline_sofa,
       s3.sofa_onset - b.baseline_sofa AS dsofa
FROM apar_cohort_1865 c
LEFT JOIN LATERAL (
    SELECT so.sofa_24hours AS sofa_onset
    FROM mimiciv_derived.sofa so
    WHERE so.stay_id = c.stay_id
      AND c.sepsis_onset_time IS NOT NULL
      AND so.starttime BETWEEN c.sepsis_onset_time - INTERVAL '30 minutes'
                            AND c.sepsis_onset_time + INTERVAL '30 minutes'
    ORDER BY ABS(EXTRACT(EPOCH FROM (so.starttime - c.sepsis_onset_time)))
    LIMIT 1
) s3 ON TRUE
LEFT JOIN LATERAL (
    SELECT MIN(so.sofa_24hours) AS baseline_sofa
    FROM mimiciv_derived.sofa so
    WHERE so.stay_id = c.stay_id
      AND c.suspected_infection_time IS NOT NULL
      AND so.starttime >= c.suspected_infection_time - INTERVAL '48 hours'
      AND so.starttime <  c.suspected_infection_time
) b ON TRUE;

SELECT COUNT(*)                                AS n_total,
       COUNT(*) FILTER (WHERE baseline_sofa IS NULL) AS n_baseline_missing,
       COUNT(*) FILTER (WHERE dsofa >= 2)      AS n_dsofa_ge_2
FROM tmp_dsofa;
-- expected: 1,865 / 1,102 / 382
--   (n_total / n_baseline_missing / n_dsofa_ge_2)
-- NOTE: the analysis-7 cohort is NOT the 382 patients with dSOFA >= 2 alone.
-- It is the 1,102 patients with no computable baseline (retained, see above)
-- PLUS the 382 with dSOFA >= 2, i.e. 1,484 patients, and it is these 1,484
-- that give n = 1,459 after the complete-case restriction.

/* ============================================================================
   END OF FILE
   ============================================================================ */
