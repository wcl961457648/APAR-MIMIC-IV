# data/ — inputs you generate yourself

This directory is **empty in the distributed package** (only this README ships in
the zip): MIMIC-IV is a credentialed, patient-level resource and cannot be
redistributed, so no individual-level data are shipped here.

Locally you can simply drop the eleven files listed below into this folder and
every script then runs with **zero configuration** — `resolve_path()` picks them
up automatically. If you prefer to keep them elsewhere, export `APAR_LEGACY_DIR` or
the per-file `APAR_*` variables, or use the command-line flags.

Everything the analysis needs is rebuilt from MIMIC-IV v3.1 with the queries in
`../sql/`. Run them in order and drop the outputs into this folder (or point the
environment variables / command-line flags anywhere else you prefer).

## Required files

| File | Built by | Used by |
|---|---|---|
| `cohort_v2.xlsx` | `sql/01_cohort_extraction.sql` (export the final `apar_cohort_1865` view) | every module, via `load_cohort()` |
| `derived_v2.xlsx` | aetiology / ACLF / organ-failure derivation, one row per `stay_id` | every module, via `load_cohort()` |
| `cohort_v2_raw.csv` | the same extraction, **before** the complete-case restriction | `09_missingness.py` |
| `cohort_v2_extras.csv` | the extraction with the timestamp columns added | `10_timing.py` |
| `bmi.csv` | `sql/05_bmi_extraction.sql` (first ICU day height × weight; `stay_id,bmi`) | `09_missingness.py` (`--bmi`) |

Expected size after `sql/01`: 3,068 adults with cirrhosis and Sepsis-3 during
their first ICU stay → 1,927 with ALP and albumin within 24 h → **1,865** after
excluding deaths within 24 h of ICU admission.

## Outcome columns in `cohort_v2.xlsx`

| Column | Meaning |
|---|---|
| `death_30d` / `death_90d` | all-cause death within 30 / 90 days of ICU admission, from `patients.dod` |
| `death_within_icu_30days` / `death_within_hosp_90days` | **legacy names** for exactly the same columns - kept because existing exports carry these headers |
| `survival_days_30` / `survival_days_90` | ICU admission to death in whole days, administratively censored at 30 / 90 days |
| `death_in_current_adm` | death during the index hospitalisation (supportive outcome, not modelled) |

Despite their names, `death_within_icu_30days` and `death_within_hosp_90days`
are **all-cause** endpoints: `patients.dod` links hospital records with state
death-registry records, so deaths after discharge are included. `apar_common.py`
asserts row-for-row identity with `death_30d` / `death_90d` at load time, so a
future export that changes the definitions will fail loudly instead of
silently.

## Files required only by the sensitivity analyses

| File | Built by | Used by |
|---|---|---|
| `cc_stay.csv` | `sql/03_sensitivity_cohorts.sql` §1 | `07_sensitivity.py` row 2 |
| `albumin_before_draw.csv` | `sql/03_sensitivity_cohorts.sql` §2 | row 7 |
| `dsofa_cohort.csv` | `sql/03_sensitivity_cohorts.sql` §3 | row 9 |
| `anchor_year_group.csv` | `sql/03_sensitivity_cohorts.sql` §4 | row 11 |
| `biliary.csv` | `sql/03_sensitivity_cohorts.sql` §5 | row 8 |
| `cohort_v2_incl24hdeath_raw.csv` | `sql/01` with the 24-h-death exclusion disabled | row 13 |

Any file that is missing is skipped with a `[skip]` message and the
corresponding sensitivity analysis is simply omitted from Table S5 — the rest of
the table is produced normally.

## Pointing somewhere else

Every path is resolved by `resolve_path()` in `apar_common.py`:

1. environment variable — `APAR_COHORT`, `APAR_DERIVED`, `APAR_RAW`,
   `APAR_EXTRAS`, `APAR_CC_STAY`, `APAR_ALBUMIN`, `APAR_DSOFA`, `APAR_ANCHOR`,
   `APAR_BILIARY`, `APAR_COHORT_INCL24H`, `APAR_OUTDIR`;
2. `./data/<filename>` relative to the package root (the default);
3. `$APAR_LEGACY_DIR/<filename>` — optional fallback pointing at a directory
   that holds the same file names (e.g. your copy of the extraction folder).

The per-run flags `--cohort`, `--derived`, `--outdir`, `--raw`, `--extras`,
`--cc-stay`, `--albumin`, `--dsofa`, `--anchor`, `--biliary` and
`--cohort-incl24h` always take precedence over all of the above.
