#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Harrell optimism correction for the calibration slope and calibration-in-the-large,
1,000 bootstrap resamples - the companion of the C-index optimism correction in
02_discrimination.py.

    optimism = mean_b [ statistic(model_b on its own bootstrap sample)
                        - statistic(model_b on the original cohort) ]
    corrected = apparent - mean(optimism)

Models: Model 3 (with APAR) and the same model without APAR, at 30 and 90 days,
i.e. exactly the two curves of Figure S2 and the four slopes reported in the
manuscript.  The risk used for the logistic recalibration is 1 - S(tau), the same
quantity as in 03_calibration_dca.py; the fast evaluation
(baseline survival x partial hazard) is validated against
CoxPHFitter.predict_survival_function before the loop starts.
"""
import os
import time

import numpy as np
import pandas as pd
from lifelines import CoxPHFitter
from scipy.optimize import minimize

from apar_common import MODELS, common_args, load_cohort, survival_frame, HORIZONS

PENALIZER = 1e-6


def logistic_recalibration(p, y):
    """Fit logit(y) = a + b * logit(p); returns (a = CITL, b = slope)."""
    X = np.log(np.clip(p, 1e-9, 1 - 1e-9) / np.clip(1 - p, 1e-9, None))
    X = np.column_stack([np.ones(len(X)), X])

    def nll(b):
        z = X @ b
        return -np.mean(y * z - np.logaddexp(0, z))

    r = minimize(nll, [0.0, 1.0], method='BFGS')
    return float(r.x[0]), float(r.x[1])


def fit_cox(d, cols):
    cph = CoxPHFitter(penalizer=PENALIZER)
    cph.fit(d[cols + ['T', 'E']], duration_col='T', event_col='E', show_progress=False)
    return cph


def risk_at(cph, d, t_eval):
    """1 - S(tau); identical to predict_survival_function(d, times=[t_eval])."""
    bs = cph.baseline_survival_
    s0 = np.interp(t_eval, bs.index.values.astype(float), bs['baseline survival'].values)
    lp = cph.predict_log_partial_hazard(d).values.ravel()
    return 1 - s0 ** np.exp(lp)


def observed(d, t_eval):
    return ((d['T'].values <= t_eval) & (d['E'].values == 1)).astype(int)


def optimism_corrected(d, cols, t_eval, n_boot, seed):
    d = d.reset_index(drop=True)
    y = observed(d, t_eval)
    a_app, b_app = logistic_recalibration(risk_at(fit_cox(d, cols), d, t_eval), y)
    rng = np.random.default_rng(seed)
    idx = np.arange(len(d))
    da, db = [], []
    for _ in range(n_boot):
        s = rng.choice(idx, len(idx), replace=True)
        db_ = d.iloc[s].reset_index(drop=True)
        yb = observed(db_, t_eval)
        if yb.sum() in (0, len(db_)):
            continue
        try:
            cph = fit_cox(db_, cols)
            a_in, b_in = logistic_recalibration(risk_at(cph, db_, t_eval), yb)
            a_out, b_out = logistic_recalibration(risk_at(cph, d, t_eval), y)
            db.append(b_in - b_out)
            da.append(a_in - a_out)
        except Exception:
            pass
    da, db = np.array(da), np.array(db)
    return dict(N=len(d), Apparent_slope=b_app, Optimism_slope=float(db.mean()),
                Corrected_slope=b_app - float(db.mean()),
                Apparent_CITL=a_app, Optimism_CITL=float(da.mean()),
                Corrected_CITL=a_app - float(da.mean()), n_boot=len(db))


def main():
    parser = common_args(__doc__)
    parser.add_argument('--seed', type=int, default=20261020)
    args = parser.parse_args()
    os.makedirs(args.outdir, exist_ok=True)
    n_boot = args.n_boot if args.n_boot else 1000   # --n-boot comes from common_args

    m, _sc = load_cohort(args.cohort, args.derived)
    base_cols = [c for c in MODELS['M3'] if c != 'apar']

    print('=== validating the fast risk evaluation against predict_survival_function ===')
    for lab, cols in [('Model 3', MODELS['M3']), ('Model 3 - APAR', base_cols)]:
        for hz, T, E, te in HORIZONS:
            d = survival_frame(m, cols, T, E)
            cph = fit_cox(d, cols)
            slow = 1 - cph.predict_survival_function(d, times=[te]).values.flatten()
            print('  %-14s %s  max|difference| = %.2e'
                  % (lab, hz, np.abs(slow - risk_at(cph, d, te)).max()))

    rows = []
    print()
    for lab, cols in [('APAR + clinical (Model 3)', MODELS['M3']),
                      ('Clinical only (Model 3 - APAR)', base_cols)]:
        for hz, T, E, te in HORIZONS:
            d = survival_frame(m, cols, T, E)
            t0 = time.time()
            r = optimism_corrected(d, cols, te, n_boot, args.seed)
            rows.append(dict(Horizon=hz, Model=lab, **r))
            print('%-28s %s  slope %.4f - %.4f -> %.4f  (%d resamples, %.0f s)'
                  % (lab, hz, r['Apparent_slope'], r['Optimism_slope'],
                     r['Corrected_slope'], r['n_boot'], time.time() - t0))

    out = pd.DataFrame(rows)
    out.to_csv(f'{args.outdir}/calibration_slope_optimism.csv', index=False,
               encoding='utf-8-sig')
    print()
    print('===== Optimism-corrected calibration slope and CITL =====')
    print(out.to_string(index=False))
    print('\nwritten to', args.outdir)


if __name__ == '__main__':
    main()
