"""
Figure 1 - flow of participants through the study (24 h cohort, N = 1,865).

Layout follows the two-column flow-chart template: three boxes down the left
hand column joined by vertical arrows, and the two exclusion boxes set off to
the right on horizontal stubs, so that 3,068 - 1,141 - 62 = 1,865 reads straight
down the page.  The wording and all counts are this study's own; nothing is
copied from the template.

The entry box carries cirrhosis and Sepsis-3 together (n = 3,068); the count of
adults with cirrhosis admitted to an ICU (4,115 patients, 6,597 ICU stays) is
reported in the manuscript text rather than as a separate box.

Counts are hard-coded from the cohort construction and must agree with
Supplementary File 1 (01_cohort_extraction.sql, STEP 10):

    t_icu                     4,115 adults with cirrhosis, 6,597 ICU stays
       -> Sepsis-3 met in 3,068 patients (earliest such stay per patient)
    -1,141 without either an ALP or an albumin measurement within 24 h
    -   62 death within 24 h of ICU admission
    =1,865 analytic cohort

Patients with APAR above mean + 3 SD (n = 36) are RETAINED in the primary
analysis and are removed only in sensitivity analysis 3; this is stated in the
manuscript figure legend rather than shown as an exclusion box.

The canvas deliberately carries no title and no footnote - those belong to the
manuscript, not to the exported image.
"""
import os

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import FancyArrowPatch, Rectangle

from apar_common import common_args

# Serif face, to match the typography of the journal's flow-chart style.
for _f in ('C:/Windows/Fonts/times.ttf', 'C:/Windows/Fonts/timesbd.ttf',
           'C:/Windows/Fonts/timesi.ttf', 'C:/Windows/Fonts/timesbi.ttf'):
    if os.path.exists(_f):
        font_manager.fontManager.addfont(_f)
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['axes.unicode_minus'] = False

INK = '#1a1a1a'
EDGE = '#2b2b2b'


def main():
    a = common_args('Figure 1 flow diagram').parse_args()
    os.makedirs(a.outdir, exist_ok=True)

    # Coordinates in inches so that box proportions are literal: 8.8 x 5.0 in
    # (aspect 1.76) fits the 6 in text width at ~3.4 in tall in the manuscript.
        # 180 mm native layout: 7.007 in + pad_inches 0.04 -> 2126 px at 300 dpi.
    # Rendered at 300 dpi and never resampled, so the point sizes below are
    # the point sizes in the printed figure.
    fig, ax = plt.subplots(figsize=(7.007, 3.981), dpi=300)
    ax.set_xlim(0, 8.8)
    ax.set_ylim(0, 5.0)
    ax.axis('off')

    MAIN_X, MAIN_W, MAIN_H = 0.15, 3.90, 0.95
    SIDE_X, SIDE_W = 4.75, 3.90

    def box(x, y, w, h, fc, ec=EDGE, lw=1.5, r=0.0):
        ax.add_patch(Rectangle((x, y), w, h, facecolor=fc, edgecolor=ec,
                               linewidth=lw, zorder=2, joinstyle='miter'))

    def centered(x, y, w, h, text, fs=11.0, bold=False):
        ax.text(x + w / 2, y + h / 2, text, ha='center', va='center',
                fontsize=fs, fontweight='bold' if bold else 'normal',
                color=INK, zorder=3, linespacing=1.32)

    def excluded_box(x, y, w, h, text, fs=10.4):
        """Red exclusion box sitting to the right of the vertical flow."""
        ax.add_patch(Rectangle((x, y), w, h, facecolor='#fbe6e6',
                               edgecolor='#a63939', linewidth=1.5,
                               zorder=2, joinstyle='miter'))
        ax.text(x + w / 2, y + h / 2, text, ha='center', va='center',
                fontsize=fs, color=INK, zorder=3, linespacing=1.40)

    def arrow(x1, y1, x2, y2, lw=1.5):
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle='-|>',
                                     mutation_scale=13, linewidth=lw,
                                     color=EDGE, shrinkA=0, shrinkB=0,
                                     zorder=1))

    # ---- left column: three stages, with the two exclusions set off to
    # the right so that the arithmetic 3,068 - 1,141 - 62 = 1,865 reads
    # straight down the page.
    BLUE = '#1f3864'
    y1_top, y2_top, y3_top = 4.85, 3.05, 1.30
    H1, H2, H3 = 1.05, 1.00, 0.95

    box(MAIN_X, y1_top - H1, MAIN_W, H1, '#dbe7f3', ec=BLUE, lw=1.8)
    centered(MAIN_X, y1_top - H1, MAIN_W, H1,
             'Adult ICU patients with cirrhosis\n'
             'AND Sepsis-3 criteria\n'
             '(first stay meeting Sepsis-3; n = 3,068)',
             fs=11.0, bold=True)

    box(MAIN_X, y2_top - H2, MAIN_W, H2, '#eaf1f8', ec=BLUE, lw=1.8)
    centered(MAIN_X, y2_top - H2, MAIN_W, H2,
             'Both ALP and albumin measured\n'
             'within 24 h of ICU admission\n'
             '(n = 1,927)',
             fs=11.0)

    box(MAIN_X, y3_top - H3, MAIN_W, H3, '#d9e8d5', ec=BLUE, lw=1.8)
    centered(MAIN_X, y3_top - H3, MAIN_W, H3,
             'Included in the primary analysis\n'
             '(n = 1,865)',
             fs=11.0, bold=True)

    # ---- vertical flow and the two exclusion stubs ----------------------
    cx = MAIN_X + MAIN_W / 2
    arrow(cx, y1_top - H1, cx, y2_top, lw=1.4)
    arrow(cx, y2_top - H2, cx, y3_top, lw=1.4)

    y_exc1 = (y1_top - H1 + y2_top) / 2           # 3.425
    y_exc2 = (y2_top - H2 + y3_top) / 2           # 1.675
    arrow(cx, y_exc1, SIDE_X, y_exc1, lw=1.4)
    arrow(cx, y_exc2, SIDE_X, y_exc2, lw=1.4)

    # ---- right column: exclusions ---------------------------------------
    # "absence of an ALP or albumin measurement" matches the wording of the
    # manuscript legend: one or other missing, not both.
    excluded_box(SIDE_X, y_exc1 - 0.50, SIDE_W, 1.00,
                 'Excluded (n = 1,141)\n'
                 'absence of an ALP or albumin measurement\n'
                 'within 24 h of ICU admission')

    excluded_box(SIDE_X, y_exc2 - 0.50, SIDE_W, 1.00,
                 'Excluded (n = 62)\n'
                 'death within 24 h of ICU admission')

    fig.subplots_adjust(left=0, right=1, top=1, bottom=0)

    if os.environ.get('FIG1_DEBUG'):
        # Print the data-coordinate bounding box of every text so that overflow
        # can be checked without opening the file.
        fig.canvas.draw()
        ren = fig.canvas.get_renderer()
        inv = ax.transData.inverted()
        boxes = [(MAIN_X, 4.85 - 1.05, MAIN_X + MAIN_W, 4.85),
                 (MAIN_X, 3.05 - 1.00, MAIN_X + MAIN_W, 3.05),
                 (MAIN_X, 1.30 - 0.95, MAIN_X + MAIN_W, 1.30),
                 (SIDE_X, 3.425 - 0.50, SIDE_X + SIDE_W, 3.425 + 0.50),
                 (SIDE_X, 1.675 - 0.50, SIDE_X + SIDE_W, 1.675 + 0.50)]
        for t in ax.texts:
            bb = t.get_window_extent(renderer=ren)
            x0, y0 = inv.transform((bb.x0, bb.y0))
            x1, y1 = inv.transform((bb.x1, bb.y1))
            fits = [k for k, (bx0, by0, bx1, by1) in enumerate(boxes)
                    if x0 >= bx0 - 0.02 and x1 <= bx1 + 0.02
                    and y0 >= by0 - 0.02 and y1 <= by1 + 0.02]
            print('  TEXT x %.2f..%.2f y %.2f..%.2f box=%s | %s'
                  % (x0, x1, y0, y1, fits if fits else 'OUT',
                     t.get_text().replace('\n', ' | ')))

    for ext in ('png', 'pdf', 'tiff'):
        fig.savefig(os.path.join(a.outdir, f'Figure1_flowchart.{ext}'), dpi=300,
                    bbox_inches='tight', pad_inches=0.04, facecolor='white')
    print('OK: Figure1_flowchart.{png,pdf,tiff} saved to', a.outdir)


if __name__ == '__main__':
    main()
