"""
Assumption checks behind Supplementary Tables S3 and S4.

  Supplementary Table S3 - Grambsch-Therneau tests based on scaled Schoenfeld
    residuals (rank-transformed time), one row per covariate of Model 3 plus a
    GLOBAL test computed as

        U   = sum_i (g_i - gbar) * s_i          (unscaled Schoenfeld residuals)
        T   = d * U' V U / sum_i (g_i - gbar)^2 ,  df = p
        (d = number of events, V = variance matrix of the fitted Cox model)

  Supplementary Table S4 - variance inflation factors for the Model 3 covariates
    including APAR.

Because the global test indicated departure from proportionality, the manuscript
also reports the difference in restricted mean survival time (05_rmst_timevarying.py),
which does not rely on proportional hazards.
"""
import warnings

warnings.filterwarnings('ignore')

import os

import numpy as np
import pandas as pd
from lifelines import CoxPHFitter
from lifelines.statistics import proportional_hazard_test
from scipy.stats import chi2
from statsmodels.stats.outliers_influence import variance_inflation_factor

from apar_common import HORIZONS, MODELS, common_args, load_cohort, survival_frame

PENALIZER = 1e-6
COVS = MODELS['M3']


def main():
    args = common_args(__doc__).parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    m, sc = load_cohort(args.cohort, args.derived)

    rows = []
    for hz, T, E, _ in HORIZONS:
        d = survival_frame(m, COVS, T, E)
        cph = CoxPHFitter(penalizer=PENALIZER)
        cph.fit(d, duration_col='T', event_col='E', show_progress=False)

        sm = proportional_hazard_test(cph, d, time_transform='rank').summary
        for var in sm.index:
            rows.append(dict(Horizon=hz, Variable=var,
                             chi2=float(sm.loc[var, 'test_statistic']),
                             P=float(sm.loc[var, 'p'])))

        # global test
        sres = cph.compute_residuals(d, kind='schoenfeld')
        g = pd.Series(d.loc[sres.index, 'T']).rank()
        gbar = g.mean()
        U = ((g.values - gbar)[:, None] * sres[COVS].values).sum(0)
        V = cph.variance_matrix_.values
        n_events = int(d['E'].sum())
        Tglob = float(n_events * U @ V @ U / ((g.values - gbar) ** 2).sum())
        rows.append(dict(Horizon=hz, Variable='GLOBAL', chi2=Tglob,
                         P=float(chi2.sf(Tglob, len(COVS)))))
    ph = pd.DataFrame(rows)
    ph.to_csv(f'{args.outdir}/TableS3_proportional_hazards.csv', index=False, encoding='utf-8-sig')

    # --------------------------------------------------- Supplementary Table S4
    Xv = m[COVS].dropna().astype(float).assign(const=1.0)
    vif = pd.DataFrame({'Variable': Xv.columns,
                        'VIF': [variance_inflation_factor(Xv.values, i)
                                for i in range(Xv.shape[1])]})
    vif = vif[vif.Variable != 'const'].sort_values('VIF', ascending=False).reset_index(drop=True)
    vif.to_csv(f'{args.outdir}/TableS4_vif.csv', index=False, encoding='utf-8-sig')

    print('===== Supplementary Table S3: PH tests (30-day) =====')
    print(ph[ph.Horizon == '30d'].to_string(index=False))
    print('\n===== Supplementary Table S4: VIF =====')
    print(vif.to_string(index=False))
    print(f"\nmax VIF overall = {vif['VIF'].max():.2f}; "
          f"max among adjustment covariates = "
          f"{vif[vif.Variable != 'apar']['VIF'].max():.2f}")
    print('\nOutputs written to', args.outdir)


if __name__ == '__main__':
    main()
