"""
Discrimination: Table 4 of the manuscript.

  (a) Harrell's C-index of APAR and of established scores taken singly.
  (b) Change in C-index, continuous NRI and IDI when APAR is added to
      SOFA alone, to MELD-Na, to Model 3 and to Model 4 (30 and 90 days).
  (c) Optimism-corrected C-index (1,000 bootstrap resamples) for SOFA,
      MELD-Na, Model 3 and Model 4, each with and without APAR.
  (d) APAR versus ALP, head to head: change in C-index, continuous NRI and IDI
      for APAR in place of ALP, on its own, added to SOFA, and added to Model 3
      (30 and 90 days).

Uncertainty for the C-index difference, NRI and IDI comes from non-parametric
bootstrap resampling of patients with replacement, using the same model
specification as the primary analysis (Pencina et al., Stat Med 2011).

NOTE on the runtime: this is the most expensive module.  Use --n-boot 50 for a
quick smoke test.
"""
import warnings

warnings.filterwarnings('ignore')

import os

import numpy as np
import pandas as pd
from lifelines import CoxPHFitter
from lifelines.utils import concordance_index

from apar_common import HORIZONS, MODELS, common_args, load_cohort, survival_frame

PENALIZER = 1e-6


def fit_and_cindex(d, penalizer=PENALIZER):
    cph = CoxPHFitter(penalizer=penalizer)
    cph.fit(d, duration_col='T', event_col='E', show_progress=False)
    return cph


def cindex_shift_ci(d, n_boot=300, seed=3):
    """C-index with a shift-corrected (recentered) bootstrap percentile CI.

    Bootstrapping with replacement systematically lowers Harrell's C, because
    duplicated patients reduce the proportion of comparable pairs.  The
    bootstrap distribution is therefore recentered on the point estimate before
    the percentiles are taken:

        bias = median(bs) - c0 ;  CI = percentiles of (bs - bias)

    `reset_index(drop=True)` is mandatory: lifelines' concordance_index_
    collapses towards 0.5 when the fitted frame carries duplicated index labels
    (coefficients and predictions are unaffected, only the C attribute).
    """
    c0 = fit_and_cindex(d).concordance_index_
    rng = np.random.default_rng(seed)
    idx = np.arange(len(d))
    bs = []
    for _ in range(n_boot):
        try:
            db = d.iloc[rng.choice(idx, len(idx), replace=True)].reset_index(drop=True)
            bs.append(fit_and_cindex(db).concordance_index_)
        except Exception:
            pass
    bs = np.array(bs)
    bs_shift = bs - (np.median(bs) - c0)
    return c0, float(np.percentile(bs_shift, 2.5)), float(np.percentile(bs_shift, 97.5))


def dc_shift_ci(d_base, d_new, n_boot=300, seed=5):
    """Paired difference in C-index with a recentered bootstrap CI and P value."""
    c0 = (fit_and_cindex(d_new).concordance_index_
          - fit_and_cindex(d_base).concordance_index_)
    rng = np.random.default_rng(seed)
    idx = np.arange(len(d_base))
    bs = []
    for _ in range(n_boot):
        s = rng.choice(idx, len(idx), replace=True)
        try:
            bs.append(fit_and_cindex(d_new.iloc[s].reset_index(drop=True)).concordance_index_
                      - fit_and_cindex(d_base.iloc[s].reset_index(drop=True)).concordance_index_)
        except Exception:
            pass
    bs = np.array(bs)
    bs_shift = bs - (np.median(bs) - c0)
    p = 2.0 * min((bs_shift <= 0).mean(), (bs_shift >= 0).mean())
    return (c0, float(np.percentile(bs_shift, 2.5)), float(np.percentile(bs_shift, 97.5)),
            float(min(1.0, p)))


def single_predictor_cindex(m, T, E, n_boot=300):
    singles = {
        'APAR alone': ['apar'], 'ALP alone': ['ALP'], 'Albumin alone': ['ALB'],
        'SOFA alone': ['sofa'], 'APS III alone': ['apsiii'], 'OASIS alone': ['oasis'],
        'MELD alone': ['meld_plain'], 'MELD-Na alone': ['meld_na'],
        'Age alone': ['age'], 'Sex alone': ['gender'],
    }
    nested = {
        'SOFA (base)': ['sofa'],
        'SOFA + APAR': ['sofa', 'apar'],
        'MELD-Na (base)': ['meld_na'],
        'MELD-Na + APAR': ['meld_na', 'apar'],
        'M3 (base)': [c for c in MODELS['M3'] if c != 'apar'],
        'M3 + APAR': MODELS['M3'],
        'M4 (base)': [c for c in MODELS['M4'] if c != 'apar'],
        'M4 + APAR': MODELS['M4'],
    }
    out = []
    for lab, cols in {**singles, **nested}.items():
        c, lo, hi = cindex_shift_ci(survival_frame(m, cols, T, E), n_boot=n_boot)
        out.append(dict(Model=lab, C=c, lo=lo, hi=hi))
    return out


def risk_at_t(cph, d, t_eval):
    """Predicted event probability 1 - S(t) at the evaluation horizon.

    Predicted probabilities (not partial hazards) are required for valid NRI
    and IDI values.
    """
    return 1 - cph.predict_survival_function(d, times=[t_eval]).values.flatten()


def nri_idi(d_base, d_new, t_eval, n_boot=300, seed=11):
    cb = fit_and_cindex(d_base)
    cn = fit_and_cindex(d_new)
    pb, pn = risk_at_t(cb, d_base, t_eval), risk_at_t(cn, d_new, t_eval)
    obs = ((d_base['T'].values <= t_eval) & d_base['E'].values.astype(bool))

    def _nri(a, b, o):
        up, dn = b > a, b < a
        return ((up[o].mean() - dn[o].mean()) + (dn[~o].mean() - up[~o].mean()))

    def _idi(a, b, o):
        return ((b[o].mean() - a[o].mean()) - (b[~o].mean() - a[~o].mean()))

    nri, idi = _nri(pb, pn, obs), _idi(pb, pn, obs)

    rng = np.random.default_rng(seed)
    idx = np.arange(len(d_base))
    bn, bi = [], []
    for _ in range(n_boot):
        s = rng.choice(idx, len(idx), replace=True)
        db, dn_ = d_base.iloc[s], d_new.iloc[s]
        try:
            qb = risk_at_t(fit_and_cindex(db), db, t_eval)
            qn = risk_at_t(fit_and_cindex(dn_), dn_, t_eval)
            o2 = ((db['T'].values <= t_eval) & db['E'].values.astype(bool))
            bn.append(_nri(qb, qn, o2))
            bi.append(_idi(qb, qn, o2))
        except Exception:
            pass
    return dict(C_base=cb.concordance_index_, C_new=cn.concordance_index_,
                dC=cn.concordance_index_ - cb.concordance_index_,
                NRI=nri, NRI_lo=np.percentile(bn, 2.5), NRI_hi=np.percentile(bn, 97.5),
                NRI_events=float((pn[obs] > pb[obs]).mean() - (pn[obs] < pb[obs]).mean()),
                NRI_nonevents=float((pn[~obs] < pb[~obs]).mean() - (pn[~obs] > pb[~obs]).mean()),
                IDI=idi, IDI_lo=np.percentile(bi, 2.5), IDI_hi=np.percentile(bi, 97.5))


def optimism_corrected(d, cov, n_boot=1000, seed=20260910):
    """Apparent C, mean optimism, and optimism-corrected C (Harrell's method).

    optimism = mean_b [ C(model_b on its own bootstrap sample)
                        - C(model_b on the original sample) ]

    Two lifelines specifics matter here and are preserved deliberately:
      * the bootstrap frame must be reset_index(drop=True) - duplicated index
        labels make concordance_index_ collapse towards 0.5;
      * lifelines' concordance_index() treats higher scores as longer survival,
        so the partial hazard is negated.
    """
    dd = d[cov + ['T', 'E']].dropna().reset_index(drop=True)
    c_app = fit_and_cindex(dd).concordance_index_
    rng = np.random.default_rng(seed)
    idx = np.arange(len(dd))
    T_, E_ = dd['T'].values, dd['E'].values
    cin, cout = [], []
    for _ in range(n_boot):
        db = dd.iloc[rng.choice(idx, len(idx), replace=True)].reset_index(drop=True)
        try:
            cb = fit_and_cindex(db)
            cin.append(cb.concordance_index_)
            cout.append(concordance_index(T_, -cb.predict_partial_hazard(dd).values.ravel(), E_))
        except Exception:
            pass
    cin, cout = np.array(cin), np.array(cout)
    return dict(Apparent_C=c_app, C_bootstrap_on_bootstrap=float(cin.mean()),
                C_bootstrap_on_original=float(cout.mean()),
                Optimism=float((cin - cout).mean()),
                Corrected_C=c_app - float((cin - cout).mean()), N=len(dd))


def main():
    parser = common_args(__doc__)
    parser.add_argument('--n-boot-nri', type=int, default=300)
    parser.add_argument('--n-boot-opt', type=int, default=1000)
    parser.add_argument('--n-boot-cindex', type=int, default=300)
    args = parser.parse_args()
    os.makedirs(args.outdir, exist_ok=True)
    n_nri = args.n_boot if args.n_boot else args.n_boot_nri
    n_opt = args.n_boot if args.n_boot else args.n_boot_opt
    n_cindex = args.n_boot if args.n_boot else args.n_boot_cindex

    m, sc = load_cohort(args.cohort, args.derived)
    print(f"N = {sc['N']} | n_boot(NRI/IDI) = {n_nri} | n_boot(optimism) = {n_opt}")

    # ------------------------------------------------ (a) single predictors
    crows = []
    for hz, T, E, _ in HORIZONS:
        for r in single_predictor_cindex(m, T, E, n_boot=n_cindex):
            crows.append(dict(Horizon=hz, **r))
    cind = pd.DataFrame(crows)
    cind.to_csv(f'{args.outdir}/Table4_Cindex.csv', index=False, encoding='utf-8-sig')

    # ------------------------------------------------ (b) incremental value
    comparisons = [
        ('SOFA vs SOFA + APAR', ['sofa'], ['sofa', 'apar']),
        ('MELD-Na vs MELD-Na + APAR', ['meld_na'], ['meld_na', 'apar']),
        ('Model 3 vs Model 3 + APAR', [c for c in MODELS['M3'] if c != 'apar'], MODELS['M3']),
        ('Model 4 vs Model 4 + APAR', [c for c in MODELS['M4'] if c != 'apar'], MODELS['M4']),
    ]
    comp = []
    for hz, T, E, te in HORIZONS:
        for lab, b_cols, n_cols in comparisons:
            db = survival_frame(m, b_cols, T, E)
            dn = survival_frame(m, n_cols, T, E)
            common = db.index.intersection(dn.index)
            db, dn = db.loc[common], dn.loc[common]
            dc, dc_lo, dc_hi, dc_p = dc_shift_ci(db, dn, n_boot=n_nri)
            r = nri_idi(db, dn, te, n_boot=n_nri)
            r.pop('dC', None)               # replaced by the paired-bootstrap value
            comp.append(dict(Horizon=hz, Comparison=lab,
                             dC=dc, dC_lo=dc_lo, dC_hi=dc_hi, dC_P=dc_p, **r))
    comp = pd.DataFrame(comp)
    comp.to_csv(f'{args.outdir}/Table4_incremental_NRI_IDI.csv', index=False, encoding='utf-8-sig')

    # ------------------------------------------------ (c) optimism correction
    opt_rows = []
    models_opt = [
        ('SOFA', ['sofa']),
        ('SOFA + APAR', ['sofa', 'apar']),
        ('MELD-Na base', ['meld_na']),
        ('MELD-Na + APAR', ['meld_na', 'apar']),
        ('Model 3 base', [c for c in MODELS['M3'] if c != 'apar']),
        ('Model 3 + APAR', MODELS['M3']),
        ('Model 4 base', [c for c in MODELS['M4'] if c != 'apar']),
        ('Model 4 + APAR', MODELS['M4']),
    ]
    for hz, T, E, _ in HORIZONS:
        d = m.rename(columns={T: 'T', E: 'E'})
        for name, cov in models_opt:
            opt_rows.append(dict(Horizon=hz, Model=name,
                                 **optimism_corrected(d, cov, n_boot=n_opt)))
    opt = pd.DataFrame(opt_rows)
    opt.to_csv(f'{args.outdir}/Table4_optimism_corrected_Cindex.csv', index=False, encoding='utf-8-sig')

    # --------------------------------- (d) APAR versus ALP, head to head ----
    # Sign: C(APAR model) - C(ALP model); negative means APAR is worse.
    # The three comparisons ask the same question at increasing levels of
    # adjustment: is the ALP/Albumin *ratio* worth more than the ALP numerator
    # it is built from, (i) on its own, (ii) on top of SOFA, and (iii) inside
    # the fully adjusted Model 3.
    m3_no_apar = [c for c in MODELS['M3'] if c != 'apar']
    versus = [
        ('APAR alone vs ALP alone', ['ALP'], ['apar']),
        ('SOFA + APAR vs SOFA + ALP', ['sofa', 'ALP'], ['sofa', 'apar']),
        ('Model 3 + APAR vs Model 3 (ALP)', m3_no_apar + ['ALP'], MODELS['M3']),
    ]
    vs_rows = []
    for hz, T, E, te in HORIZONS:
        for lab, b_cols, n_cols in versus:
            db = survival_frame(m, b_cols, T, E)
            dn = survival_frame(m, n_cols, T, E)
            common = db.index.intersection(dn.index)
            db, dn = db.loc[common], dn.loc[common]
            dc, dc_lo, dc_hi, dc_p = dc_shift_ci(db, dn, n_boot=n_nri)
            r = nri_idi(db, dn, te, n_boot=n_nri)
            r.pop('dC', None)               # replaced by the paired-bootstrap value
            vs_rows.append(dict(Horizon=hz, Comparison=lab,
                                dC=dc, dC_lo=dc_lo, dC_hi=dc_hi, dC_P=dc_p, **r))
    versus_df = pd.DataFrame(vs_rows)
    versus_df.to_csv(f'{args.outdir}/Table4_APAR_vs_ALP.csv', index=False, encoding='utf-8-sig')

    pd.set_option('display.width', 250)
    print('\n===== Single-predictor C-index =====')
    print(cind.to_string(index=False))
    print('\n===== Incremental value of APAR =====')
    print(comp[['Horizon', 'Comparison', 'dC', 'dC_lo', 'dC_hi', 'dC_P',
                'NRI', 'NRI_lo', 'NRI_hi', 'IDI', 'IDI_lo', 'IDI_hi']]
          .to_string(index=False))
    print('\n===== Optimism-corrected C-index =====')
    print(opt.to_string(index=False))
    print('\n===== APAR versus ALP (negative = APAR worse) =====')
    print(versus_df[['Horizon', 'Comparison', 'dC', 'dC_lo', 'dC_hi', 'dC_P',
                     'NRI', 'NRI_lo', 'NRI_hi', 'IDI', 'IDI_lo', 'IDI_hi']]
          .to_string(index=False))
    print('\nOutputs written to', args.outdir)


if __name__ == '__main__':
    main()
