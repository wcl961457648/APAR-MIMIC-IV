"""
Calibration and clinical usefulness: Supplementary Figures S2 and S3 and the
calibration statistics quoted in the Results.

  * calibration curves in deciles of predicted risk (Model 3 with APAR vs the
    same model without APAR), 30 and 90 days -> Supplementary Figure S2
  * calibration slope and calibration-in-the-large from logistic recalibration
    of the predicted risks, with bootstrap 95% CIs
  * decision curve analysis -> Supplementary Figure S3

Neither exported figure carries an in-image title or footnote: the manuscript
figure legends carry the captions.  Both figures label their panels A (30-day)
and B (90-day) in the top-left corner, matching the "(A)/(B)" wording of the
legends.
"""
import warnings

warnings.filterwarnings('ignore')

import os

import matplotlib

matplotlib.use('Agg')

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from lifelines import CoxPHFitter
from scipy.optimize import minimize

from apar_common import HORIZONS, MODELS, common_args, load_cohort, survival_frame

PENALIZER = 1e-6
GREY40, PRIMARY, ACCENT = '#666666', '#b2182b', '#2166ac'


def fit_risk(m, cols, T, E, t_eval):
    """Cox model + predicted event probability 1 - S(tau)."""
    d = survival_frame(m, cols, T, E)
    cph = CoxPHFitter(penalizer=PENALIZER)
    cph.fit(d, duration_col='T', event_col='E', show_progress=False)
    risk = 1 - cph.predict_survival_function(d, times=[t_eval]).values.flatten()
    d = d.assign(pred=risk)
    obs = ((d['T'].values <= t_eval) & (d['E'].values == 1)).astype(int)
    return cph, d, risk, obs


def decile_calibration(d, risk, t_eval, n_groups=10):
    """Observed vs predicted risk in n_groups risk groups."""
    dd = d.assign(pred=risk).sort_values('pred')
    dd['dec'] = pd.qcut(dd['pred'], n_groups, labels=False, duplicates='drop')
    g = dd.groupby('dec').apply(
        lambda g: pd.Series({'pred': g['pred'].mean(),
                             'obs': (((g['T'] <= t_eval) & (g['E'] == 1)).sum()) / len(g)}),
        include_groups=False)
    return g['pred'].values, g['obs'].values


def logistic_recalibration(p, y):
    """Fit logit(y) = a + b * logit(p); returns (a = CITL, b = slope)."""
    X = np.log(np.clip(p, 1e-9, 1 - 1e-9) / np.clip(1 - p, 1e-9, None))
    X = np.column_stack([np.ones(len(X)), X])

    def nll(b):
        z = X @ b
        return -np.mean(y * z - np.logaddexp(0, z))

    r = minimize(nll, [0.0, 1.0], method='BFGS')
    return float(r.x[0]), float(r.x[1])


def calibration_with_ci(m, cols, T, E, t_eval, n_boot=500, seed=42):
    _, d, risk, y = fit_risk(m, cols, T, E, t_eval)
    a0, b0 = logistic_recalibration(risk, y)
    rng = np.random.default_rng(seed)
    aa, bb = [], []
    for _ in range(n_boot):
        s = rng.integers(0, len(d), len(d))
        if y[s].sum() in (0, len(s)):
            continue
        try:
            a, b = logistic_recalibration(risk[s], y[s])
            aa.append(a)
            bb.append(b)
        except Exception:
            pass
    return dict(CITL=a0, CITL_lo=np.percentile(aa, 2.5), CITL_hi=np.percentile(aa, 97.5),
                slope=b0, slope_lo=np.percentile(bb, 2.5), slope_hi=np.percentile(bb, 97.5),
                n_boot=len(aa))


def net_benefit(d, risk, t_eval, prevalence=None):
    obs = ((d['T'] <= t_eval) & (d['E'] == 1)).astype(int).values
    N = len(obs)
    pts = np.linspace(0.01, 0.5, 50)
    nb = []
    for p in pts:
        tr = (risk >= p).astype(int)
        TP = ((tr == 1) & (obs == 1)).sum()
        FP = ((tr == 1) & (obs == 0)).sum()
        nb.append(TP / N - FP / N * p / (1 - p))
    return pts, np.array(nb), float(obs.mean())


def main():
    parser = common_args(__doc__)
    parser.add_argument('--n-boot-cal', type=int, default=500)
    args = parser.parse_args()
    os.makedirs(args.outdir, exist_ok=True)
    n_boot = args.n_boot if args.n_boot else args.n_boot_cal

    m, sc = load_cohort(args.cohort, args.derived)
    base_cols = [c for c in MODELS['M3'] if c != 'apar']

    # ------------------------------------------- Supplementary Figure S2
        # 180 mm native layout: rendered at 300 dpi and never resampled, so the
    # point sizes below are the point sizes in the printed figure.
    fig, axs = plt.subplots(1, 2, figsize=(7.188, 2.876), dpi=300)
    for ax, (hz, T, E, te), lbl in zip(axs, HORIZONS, ['A', 'B']):
        ax.plot([0, 1], [0, 1], '--', color=GREY40, lw=.8)
        for cols, lab, col, mk in [(MODELS['M3'], 'APAR + clinical (Model 3)', PRIMARY, 'o'),
                                   (base_cols, 'Clinical only (Model 3 - APAR)', ACCENT, 's')]:
            _, d, risk, _ = fit_risk(m, cols, T, E, te)
            xp, yp = decile_calibration(d, risk, te)
            ax.plot(xp, yp, mk + '-', color=col, ms=5, label=lab)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_xlabel('Predicted risk', fontsize=9)
        # Only the left panel carries the y label: both panels plot the same
        # quantity, and at 180 mm a second label collides with the x label of
        # the panel to its left.
        ax.set_ylabel('Observed risk' if lbl == 'A' else '', fontsize=9)
        ax.set_title(f'{hz.replace("d", "-day")} mortality')
        ax.legend(loc='upper left', fontsize=7.5)
        # Panel letter in the top-left corner, level with the panel title and
        # drawn in axes coordinates so it sits outside the data area.
        ax.text(0.0, 1.02, lbl, transform=ax.transAxes, ha='left', va='bottom',
                fontsize=13, fontweight='bold', color='black')
    # No in-figure title: the manuscript figure legend carries it.
    fig.tight_layout(w_pad=2.4)
    for ext in ['png', 'pdf', 'tiff']:
        fig.savefig(f'{args.outdir}/FigureS2_calibration.{ext}', dpi=300, bbox_inches='tight')
    plt.close(fig)

    # ------------------------------------------- Supplementary Figure S3
        # 180 mm native layout: rendered at 300 dpi and never resampled, so the
    # point sizes below are the point sizes in the printed figure.
    fig, axs = plt.subplots(1, 2, figsize=(7.188, 2.876), dpi=300)
    for ax, (hz, T, E, te), lbl in zip(axs, HORIZONS, ['A', 'B']):
        _, d1, r1, _ = fit_risk(m, MODELS['M3'], T, E, te)
        p1, n1, prev = net_benefit(d1, r1, te)
        _, d0, r0, _ = fit_risk(m, base_cols, T, E, te)
        p2, n2, _ = net_benefit(d0, r0, te)
        ax.plot(p1, n1, color=PRIMARY, lw=2, label='APAR + clinical (Model 3)')
        ax.plot(p2, n2, color=ACCENT, lw=2, label='Clinical only (Model 3 - APAR)')
        ax.plot(p1, prev - (1 - prev) * p1 / (1 - p1), '--', color=GREY40, lw=.8, label='Treat all')
        ax.axhline(0, color=GREY40, lw=.8, ls=':', label='Treat none')
        ax.set_xlim(0, .5)
        # Upper limit 0.43, not 0.35: net benefit at a threshold of 0 equals the
        # event rate, which is 0.405 at 90 days, so the 0.35 limit cut the left
        # end off the curves in panel B.
        ax.set_ylim(-.45, .43)
        ax.set_xlabel('Threshold probability', fontsize=9)
        ax.set_ylabel('Net benefit' if lbl == 'A' else '', fontsize=9)
        ax.set_title(f'{hz.replace("d", "-day")} mortality')
        # lower left is the only region left empty by the two curves and by the
        # treat-all line; 'upper right' hid the curves for thresholds > 0.2
        ax.legend(loc='lower left', fontsize=7.5)
        # Panel letter in the top-left corner, level with the panel title and
        # drawn in axes coordinates so it sits outside the data area.
        ax.text(0.0, 1.02, lbl, transform=ax.transAxes, ha='left', va='bottom',
                fontsize=13, fontweight='bold', color='black')
    # No in-figure title: the manuscript figure legend carries it.
    fig.tight_layout(w_pad=2.4)
    for ext in ['png', 'pdf', 'tiff']:
        fig.savefig(f'{args.outdir}/FigureS3_DCA.{ext}', dpi=300, bbox_inches='tight')
    plt.close(fig)

    # ------------------------------------------- calibration statistics
    rows = []
    for hz, T, E, te in HORIZONS:
        for lab, cols in [('APAR + clinical (Model 3)', MODELS['M3']),
                          ('Clinical only (Model 3 - APAR)', base_cols)]:
            rows.append(dict(Horizon=hz, Model=lab,
                             **calibration_with_ci(m, cols, T, E, te, n_boot=n_boot)))
    calib = pd.DataFrame(rows)
    calib.to_csv(f'{args.outdir}/calibration_slope_CITL.csv', index=False, encoding='utf-8-sig')

    print('===== Calibration slope and calibration-in-the-large =====')
    print(calib.to_string(index=False))
    print('\nFigures S2 and S3 written to', args.outdir)


if __name__ == '__main__':
    main()
