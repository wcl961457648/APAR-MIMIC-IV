"""
Figure 4 and Supplementary Table S6: prespecified subgroup analyses.

Subgroup-specific HRs are reported per 1-SD increase in APAR (4.71 units on the
albumin-in-g/L scale) at 30 and 90 days, using Model 3.  Interaction P values
come from a Model 3 that additionally contains the subgroup indicator and its
product term with APAR.  In the forest plot the side length of the square
marker is set to 8 * sqrt(n / n_max) points, so marker size increases with
subgroup size.  Strictly the drawn area is only approximately proportional to
n, because matplotlib adds a 1-point edge stroke on top of the side length;
area/n varies by up to 11% across subgroups.  The legend therefore states only
that marker size increases with subgroup size.

Layout.  The two horizons are drawn side by side, as in the original figure,
but they now share a single subgroup column.  The subgroup membership and the
group sizes are identical at 30 and 90 days (only the event counts and the HRs
differ), so printing the labels twice would have cost about 48 mm of width
without adding information.  Frontiers sets a double-column figure at 180 mm
(2126 px at 300 dpi); with the labels printed twice, the longest label
("Other (non-alcoholic) aetiology") no longer fitted on one line and the
estimate columns collapsed into the forest panels.  Sharing the label column
gives the two estimates about 43 mm each and keeps every number at 8 pt.

Everything is drawn natively at the final size: the figure is created at
180 mm and never resampled, so the point sizes below are the point sizes in
print.  Column widths are read back from the realised GridSpec rather than
guessed, because wspace is defined as a fraction of the average axes width and
therefore shifts every column as soon as one ratio changes.  After any change,
re-run with the bounding-box check described in the repository notes: a text
pair that overlaps reintroduces the collision this layout was built to avoid.

The P value next to each estimate uses three decimals and is replaced by the
bound "<0.001" below that threshold; two decimals would render every P between
0.001 and 0.005 as "0.00".  A "P" header sits above that column, so the values
are printed without a "p =" prefix.
"""
import warnings

warnings.filterwarnings('ignore')

import os

import matplotlib

matplotlib.use('Agg')

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from lifelines import CoxPHFitter
from matplotlib.gridspec import GridSpec
from matplotlib.text import Text

from apar_common import ADJ, HORIZONS, common_args, load_cohort, survival_frame

PENALIZER = 1e-6
PRIMARY, GREY40 = '#b2182b', '#666666'

# ---- figure geometry ------------------------------------------------------
# Kept in one block because the numbers are coupled: the label column must hold
# the longest wrapped subgroup label plus its n= count, the numbers columns must
# hold a full "1.13 (1.05-1.22)" string plus its P value, and the two forests
# must still show readable tick labels.  The figure is 180 mm wide and the grid
# is not resampled, so FIG_W only has to be large enough that bbox_inches='tight'
# trims it back to 2126 px; the ratios below decide how the width is shared.
FIG_W = 8.87            # inches; tight bbox trims the side slack to 2122 px
H_TOP = 0.34            # inches; panel letter and horizon title
H_DATA = 5.95           # inches; the 12 subgroup rows and the column headers
H_INT = 1.30            # inches; interaction-P block under each horizon
WSPACE, HSPACE = .10, .34
W_RATIOS = [1.92, .68, 1.565, .68, 1.565]   # label, forest, numbers, forest, numbers
FS_LABEL, FS_N = 8.5, 8.0
FS_HR, FS_P = 8.0, 7.0
FS_TICK, FS_TITLE, FS_LETTER = 7.5, 9.5, 10.5
MS_MAX = 8.0

_fig = _rend = None


def _renderer(fig):
    """The throw-away Text objects used to measure string widths read the dpi
    from their figure, so they need a realised figure and its renderer."""
    global _fig, _rend
    _fig = fig
    fig.canvas.draw()
    _rend = fig.canvas.get_renderer()


def _tw(s, fs, mono=False):
    """Width of s in inches at font size fs, in the font actually drawn."""
    t = Text(0, 0, s, fontsize=fs)
    t.set_figure(_fig)
    if mono:
        t.set_family('monospace')
    return t.get_window_extent(_rend).width / _rend.dpi


def _wrap(s, fs, max_in):
    """Greedy wrap on spaces so that each line fits in max_in inches.

    Two subgroup labels need this at 8.5 pt: "Alcohol-related aetiology" and
    "Other (non-alcoholic) aetiology".  They are wrapped rather than shortened
    so that the figure text stays identical to Figure4_subgroup_estimates.csv
    and to Supplementary Table S6.
    """
    if _tw(s, fs) <= max_in:
        return s
    lines, cur = [], ''
    for w in s.split(' '):
        trial = (cur + ' ' + w).strip()
        if cur and _tw(trial, fs) > max_in:
            lines.append(cur)
            cur = w
        else:
            cur = trial
    lines.append(cur)
    return '\n'.join(lines)


def _pfmt(p):
    return f"{p:.3f}" if p >= .001 else "<0.001"


def subgroup_definitions(m):
    return [('Age < 65', m[m.age65 == 0]), ('Age >= 65', m[m.age65 == 1]),
            ('Male', m[m.gender == 1]), ('Female', m[m.gender == 0]),
            ('AKI', m[m.aki == 1]), ('No AKI', m[m.aki == 0]),
            ('MELD-Na < 20', m[m.meldna20 == 0]), ('MELD-Na >= 20', m[m.meldna20 == 1]),
            ('SOFA < 10', m[m.sofa10 == 0]), ('SOFA >= 10', m[m.sofa10 == 1]),
            ('Alcohol-related aetiology', m[m.aetiology == 'alcohol']),
            ('Other (non-alcoholic) aetiology', m[m.aetiology == 'non-alcohol'])]


def fit_subgroup(df, T, E, SD):
    keep = ['apar'] + [c for c in ADJ if c != 'apar' and df[c].dropna().nunique() > 1]
    dd = df[keep + [T, E]].dropna().rename(columns={T: 'T', E: 'E'})
    if len(dd) < 30 or dd['E'].sum() < 5:
        return None
    cph = CoxPHFitter(penalizer=PENALIZER)
    try:
        cph.fit(dd, 'T', 'E', show_progress=False)
    except Exception:
        return None
    s = cph.summary.loc['apar']
    return dict(n=len(dd), events=int(dd['E'].sum()),
                HR=np.exp(s['coef'] * SD), LCL=np.exp(s['coef lower 95%'] * SD),
                UCL=np.exp(s['coef upper 95%'] * SD), P=s['p'])


def interaction_p(m, var, T, E):
    d = m.copy()
    d['int'] = d['apar'] * d[var]
    cov = ['apar', var, 'int'] + [c for c in ADJ if c != var]
    cph = CoxPHFitter(penalizer=PENALIZER)
    cph.fit(survival_frame(d, cov, T, E), 'T', 'E', show_progress=False)
    return float(cph.summary.loc['int', 'p'])


def plot_subgroups(g30, g90, i30, i90, path):
    """One figure, two horizons side by side sharing the subgroup column."""
    n = len(g30)
    fig = plt.figure(figsize=(FIG_W, H_TOP + H_DATA + H_INT), dpi=300)
    _renderer(fig)
    gs = GridSpec(3, 5, width_ratios=W_RATIOS,
                  height_ratios=[H_TOP, H_DATA, H_INT],
                  wspace=WSPACE, hspace=HSPACE, figure=fig)

    a_t30, a_t90 = fig.add_subplot(gs[0, 1:3]), fig.add_subplot(gs[0, 3:5])
    a_lab = fig.add_subplot(gs[1, 0])
    a_f30, a_n30 = fig.add_subplot(gs[1, 1]), fig.add_subplot(gs[1, 2])
    a_f90, a_n90 = fig.add_subplot(gs[1, 3]), fig.add_subplot(gs[1, 4])
    a_i30, a_i90 = fig.add_subplot(gs[2, 1:3]), fig.add_subplot(gs[2, 3:5])

    for a in (a_t30, a_t90, a_lab, a_f30, a_n30, a_f90, a_n90, a_i30, a_i90):
        a.set_xticks([])
        a.set_yticks([])
        for s in a.spines.values():
            s.set_visible(False)
        # The interaction block spans two columns; a white patch would paint
        # over the tick labels of the forest panel above it.
        a.patch.set_visible(False)

    ypos = np.arange(n, 0, -1)
    for a in (a_lab, a_f30, a_n30, a_f90, a_n90):
        # n + 1.8 leaves one row of headroom for the column headers.
        a.set_ylim(0, n + 1.8)

    for a, letter, title in ((a_t30, 'A', '30-day mortality'),
                             (a_t90, 'B', '90-day mortality')):
        a.set_ylim(0, 1)
        a.set_xlim(0, 1)
        a.text(.0, .35, letter, ha='left', va='center', fontsize=FS_LETTER,
               fontweight='bold')
        a.text(.14, .35, title, ha='left', va='center', fontsize=FS_TITLE)

    # ---- realised column widths drive every horizontal position -----------
    dpi = _rend.dpi
    cw_lab = a_lab.get_window_extent(_rend).width / dpi
    cw_num = a_n30.get_window_extent(_rend).width / dpi
    w_n = max(_tw(f"n={x}", FS_N) for x in g30['n'])
    w_hr = max(_tw(f"{r.HR:.2f} ({r.LCL:.2f}-{r.UCL:.2f})", FS_HR, mono=True)
               for r in pd.concat([g30, g90]).itertuples())
    p_col = (.02 * cw_num + w_hr + .10) / cw_num   # P values right of the HR

    a_lab.text(.02, n + 1.35, 'Subgroup', ha='left', va='center',
               fontsize=FS_P, color=GREY40)
    for i, r in g30.iterrows():
        a_lab.text(.02, ypos[i], _wrap(r['Subgroup'], FS_LABEL, cw_lab - w_n - .12),
                   ha='left', va='center', fontsize=FS_LABEL, linespacing=1.15)
        a_lab.text(.99, ypos[i], f"n={r['n']}", ha='right', va='center',
                   fontsize=FS_N, color=GREY40)

    for a_f, a_n, gdf in ((a_f30, a_n30, g30), (a_f90, a_n90, g90)):
        n_max = float(gdf['n'].max())
        a_f.axvline(1, color=GREY40, lw=.8, ls='--')
        for i, (_, r) in enumerate(gdf.iterrows()):
            # Marker size increases with subgroup size, as stated in the
            # legend: for a square marker the side length scales as sqrt(n).
            # The 1-point edge stroke is why the legend does not claim the box
            # area to be proportional to n.
            a_f.errorbar(r['HR'], ypos[i],
                         xerr=[[r['HR'] - r['LCL']], [r['UCL'] - r['HR']]],
                         fmt='s', color=PRIMARY,
                         ms=MS_MAX * np.sqrt(r['n'] / n_max), capsize=2, lw=1.0)
        a_f.set_xscale('log')
        a_f.set_xlim(.85, 1.7)
        # Two ticks only.  In log coordinates on a 17-mm-wide axis the labels
        # for 1.0 and 1.2 sat 12 pt apart and merged into "1.01.2" at 300 dpi.
        # The column header names the quantity, so the axis carries no title.
        a_f.set_xticks([1.0, 1.5])
        a_f.set_xticklabels(['1.0', '1.5'], fontsize=FS_TICK)
        a_f.minorticks_off()

        a_n.text(.02, n + 1.35, 'HR (95% CI)', ha='left', va='center',
                 fontsize=FS_P, color=GREY40)
        a_n.text(p_col, n + 1.35, 'P', ha='left', va='center',
                 fontsize=FS_P, color=GREY40)
        for i, (_, r) in enumerate(gdf.iterrows()):
            a_n.text(.02, ypos[i], f"{r['HR']:.2f} ({r['LCL']:.2f}-{r['UCL']:.2f})",
                     ha='left', va='center', fontsize=FS_HR, family='monospace')
            a_n.text(p_col, ypos[i], _pfmt(r['P']), ha='left', va='center',
                     fontsize=FS_P)

    for a, idf in ((a_i30, i30), (a_i90, i90)):
        a.set_ylim(-(len(idf) + .9), 1.2)
        a.set_xlim(0, 1)
        a.text(.0, .9, 'Interaction P (Model 3):', ha='left', va='center',
               fontsize=FS_P + .5, color=GREY40)
        for j, (_, r) in enumerate(idf.iterrows()):
            a.text(.02, -.45 - j * 1.0,
                   f"{r['Variable']}: p = {r['P_interaction']:.3f}",
                   ha='left', va='center', fontsize=FS_P)

    # No in-image figure title: the manuscript figure legend carries it.
    for ext in ['png', 'pdf', 'tiff']:
        fig.savefig(f'{path}.{ext}', dpi=300, bbox_inches='tight', facecolor='white')
    plt.close(fig)


def main():
    args = common_args(__doc__).parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    m, sc = load_cohort(args.cohort, args.derived)
    SD = sc['SD_apar']
    subs = subgroup_definitions(m)

    all_sub, all_int = [], []
    for hz, T, E, _ in HORIZONS:
        rows = []
        for lab, s in subs:
            r = fit_subgroup(s, T, E, SD)
            if r:
                rows.append(dict(Horizon=hz, Subgroup=lab, **r))
        all_sub.append(pd.DataFrame(rows))

        irows = []
        for v, lab in [('aki', 'AKI'), ('age65', 'Age >= 65'), ('meldna20', 'MELD-Na >= 20'),
                       ('sofa10', 'SOFA >= 10'), ('gender', 'Sex'),
                       ('alcohol', 'Alcohol-related aetiology')]:
            try:
                irows.append(dict(Horizon=hz, Variable=lab, P_interaction=interaction_p(m, v, T, E)))
            except Exception:
                irows.append(dict(Horizon=hz, Variable=lab, P_interaction=np.nan))
        all_int.append(pd.DataFrame(irows))

    g30, g90 = all_sub
    i30, i90 = all_int
    plot_subgroups(g30, g90, i30, i90,
                   f'{args.outdir}/Figure4_subgroup_combined')

    pd.concat(all_sub, ignore_index=True).to_csv(
        f'{args.outdir}/Figure4_subgroup_estimates.csv', index=False, encoding='utf-8-sig')
    pd.concat(all_int, ignore_index=True).to_csv(
        f'{args.outdir}/TableS6_interactions.csv', index=False, encoding='utf-8-sig')

    pd.set_option('display.width', 200)
    print('===== Subgroup estimates (30-day) =====')
    print(g30.to_string(index=False))
    print('\n===== Interaction P values =====')
    print(pd.concat(all_int, ignore_index=True).pivot(index='Variable', columns='Horizon',
                                                      values='P_interaction').to_string())
    print('\nOutputs written to', args.outdir)


if __name__ == '__main__':
    main()
