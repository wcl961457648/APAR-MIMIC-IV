"""
Supplementary Figure S1 - directed acyclic graph of the assumed causal
relationships between APAR and 30-day / 90-day all-cause mortality.

The DAG is cohort-independent: it summarises the a priori causal assumptions
and the candidate confounders, so it contains no numbers from the data.  The
confounder clusters must stay in step with the manuscript Methods and with
apar_common.MODELS.  Current cluster contents (revised 2026-09-29 at the
author's request):

    Demographics                age, sex
    Severity-of-illness scores  SOFA
    Liver-specific severity     MELD, MELD-Na, ACLF, cirrhosis aetiology
    Comorbidities (ICD-9/10)    AKI
    Laboratory parameters       WBC, platelets, PT, INR, total bilirubin,
                                creatinine, sodium, lactate, pH, PaO2, PaCO2

Note that the laboratory cluster lists *candidate* confounders, including the
analytes that the >15%-missingness rule keeps out of every model (lactate, pH,
PaO2, PaCO2); the rule itself is stated in the manuscript figure legend rather
than inside the image, together with the Model 3 adjustment set (age, sex,
SOFA, MELD-Na, cirrhosis aetiology, AKI, ACLF).

The exported image carries NO in-figure title and NO in-figure footnote: the
title and the note on Model 3 adjustment live in the manuscript figure legend.

Layout: 3 columns
  Left      confounder clusters (arrows to BOTH exposure and outcome)
  Middle    exposure (APAR) --> outcome (mortality), the effect of interest
  Top right unmeasured confounders (U, dashed arrows)

Wording note (2026-10-16, at the author's request): the label on the APAR ->
mortality arrow reads "effect of interest", not "causal effect of interest",
to avoid over-claiming causality from an observational analysis and to match
the wording already used in the manuscript figure legend.
"""
import os

import matplotlib
matplotlib.use('Agg')
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

from apar_common import common_args

plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['axes.unicode_minus'] = False

BLUE, RED, GRAY, U_COLOR, ARROW = "#1f4e79", "#a4133c", "#3a4a52", "#9b2226", "#5b6b73"
FS_TITLE, FS_HEAD, FS_BODY, FS_SMALL = 15, 9.0, 7.6, 7.6
# The canvas is now the final 180 mm (7.4 in) rather than 9.6 in, so each data
# unit is ~0.23 mm narrower than before.  The point sizes were reduced by the
# same factor so that the headings still fit inside the 3.6-unit boxes.


def main():
    a = common_args('Supplementary Figure S1 (DAG)').parse_args()
    os.makedirs(a.outdir, exist_ok=True)

    # The axes window is cropped to the drawing plus the same 0.15-0.20 unit
    # margin the original layout had (x 0.20-12.85, y 0.95-10.20).  The drawing
    # spans x 0.35-12.65, y 1.21-10.05.  `bbox_inches='tight'` does NOT remove
    # the empty part of the axes, so leaving xlim/ylim at (0, 13) / (0, 10.6)
    # would keep the whitespace that the deleted title and footnote used to
    # occupy.
        # 180 mm native layout: rendered at 300 dpi and never resampled.
    fig, ax = plt.subplots(figsize=(7.257, 5.369), dpi=300)
    ax.set_xlim(0.20, 12.85)
    ax.set_ylim(0.95, 10.20)
    ax.set_aspect('equal')
    ax.axis('off')

    def box(x, y, w, h, text, fc="#ffffff", ec=GRAY, fs=FS_HEAD, fw="bold", tc=GRAY):
        ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h,
                                    boxstyle="round,pad=0.03,rounding_size=0.16",
                                    linewidth=1.4, facecolor=fc, edgecolor=ec))
        if text:
            ax.text(x, y, text, ha="center", va="center", fontsize=fs,
                    fontweight=fw, color=tc)

    def arr(x1, y1, x2, y2, color=ARROW, lw=1.0, ls="-"):
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>",
                                     mutation_scale=13, color=color, lw=lw, linestyle=ls))

    # No in-figure title: the manuscript figure legend carries it.

    # ------------------------------------------------ middle column: E -> D
    box(6.9, 7.85, 2.5, 0.90, "APAR\n(ALP / Albumin)", fc="#dde7f1", ec=BLUE,
        fs=FS_HEAD + 1, tc=BLUE)
    ax.text(8.28, 7.85, "(E)", ha="left", va="center", fontsize=10,
            color=BLUE, fontweight="bold")
    box(6.9, 4.15, 2.9, 1.00, "30-day / 90-day\nall-cause mortality",
        fc="#f7dde2", ec=RED, tc=RED)
    ax.text(8.50, 4.15, "(D)", ha="left", va="center", fontsize=10,
            color=RED, fontweight="bold")
    arr(6.9, 7.35, 6.9, 4.75, color=BLUE, lw=2.4)
    ax.text(7.05, 6.1, "effect\nof interest", ha="left", va="center",
            fontsize=9, color=BLUE, fontstyle="italic")

    # ------------------------------------------------ unmeasured confounding
    box(12.05, 9.25, 1.2, 0.58, "U", fc="#fff5f5", ec=U_COLOR, fs=13, tc=U_COLOR)
    ax.text(12.05, 8.68, "Unmeasured\nconfounders", ha="center", va="top",
            fontsize=8, color=U_COLOR, fontstyle="italic")
    arr(11.44, 9.05, 8.25, 8.12, color=U_COLOR, lw=1.3, ls=(0, (4, 2)))
    arr(11.44, 8.80, 8.42, 4.45, color=U_COLOR, lw=1.3, ls=(0, (4, 2)))

    # ------------------------------------------------ left column: clusters
    # Boxes widened 3.6 -> 4.2 units: at 180 mm the 9 pt headings
    # "Severity-of-illness scores" and "Comorbidities (ICD-9/10)" overran the
    # right edge of a 3.6-unit box.
    LX, LW = 2.42, 3.9
    clusters = [
        (9.65, 0.80, "Demographics", "age, sex"),
        (8.20, 0.80, "Severity-of-illness scores", "SOFA"),
        (6.62, 1.05, "Liver-specific severity", "MELD, MELD-Na\nACLF, cirrhosis aetiology"),
        (5.02, 1.05, "Comorbidities (ICD-9/10)", "AKI"),
        (3.32, 1.25, "Laboratory parameters",
         "WBC, platelets, PT, INR,\ntotal bilirubin, creatinine,\nsodium, lactate, pH, PaO2, PaCO2"),
    ]
    for (y, h, head, sub) in clusters:
        box(LX, y, LW, h, "", fc="#f4f6f8", ec=GRAY)
        ax.text(LX, y + h / 2 - 0.16, head, ha="center", va="top",
                fontsize=FS_HEAD, fontweight="bold", color=GRAY)
        ax.text(LX, y - 0.16, sub, ha="center", va="center",
                fontsize=FS_BODY, color=GRAY, linespacing=1.25)
        arr(LX + LW / 2, y, 5.60, 7.80, color=ARROW, lw=1.0)
        arr(LX + LW / 2, y, 5.42, 3.72, color=ARROW, lw=1.0)

    # ------------------------------------------------ legend
    leg_y = 1.55
    ax.add_patch(mpatches.Rectangle((0.35, leg_y - 0.34), 12.3, 0.68,
                                    fill=False, edgecolor="#c9c9c9", lw=0.8))
    # Spacing widened from 2.4 to 3.0 units: at 180 mm the old pitch let the
    # label of one entry run into the tag of the next.
    for (x, tag, lab, fc, ec) in [
            (0.75, "E", "Exposure (APAR)", "#dde7f1", BLUE),
            (3.75, "D", "Outcome (mortality)", "#f7dde2", RED),
            (6.75, "C", "Measured confounder", "#f4f6f8", GRAY)]:
        box(x, leg_y, 0.46, 0.32, tag, fc=fc, ec=ec, fs=8.5, tc=ec)
        ax.text(x + 0.30, leg_y, lab, ha="left", va="center",
                fontsize=FS_SMALL, color=GRAY)
    ax.plot([9.75], [leg_y], marker="s", markersize=8, markerfacecolor="#fff5f5",
            markeredgecolor=U_COLOR, markeredgewidth=1.3)
    ax.plot([9.60, 9.90], [leg_y, leg_y], color=U_COLOR, lw=1.2,
            linestyle=(0, (3, 2)))
    ax.text(10.02, leg_y, "Unmeasured confounder", ha="left", va="center",
            fontsize=FS_SMALL, color=GRAY)

    # No in-figure footnote: the Model 3 adjustment set and the >15%-missingness
    # rule are repeated in the manuscript figure legend (see 12_figureS1_dag.py
    # docstring), so nothing is lost by dropping it from the image.

    plt.tight_layout()
    for ext in ('png', 'pdf', 'tiff'):
        fig.savefig(os.path.join(a.outdir, f'FigureS1_DAG.{ext}'), dpi=300,
                    bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print('OK: FigureS1_DAG.{png,pdf,tiff} saved to', a.outdir)


if __name__ == '__main__':
    main()
