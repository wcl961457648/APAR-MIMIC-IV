"""
Supplementary Table S1 - missingness of the candidate baseline variables.

For every variable considered for the analysis, the number observed, the number
missing and the percentage missing in the analytic cohort (N = 1,865), together
with the flag "excluded because more than 15% of values are missing", which is
the rule stated in Methods section 2.5.

IMPORTANT: the analytic cohort spreadsheet is the *complete-case* file and
therefore has no missing values at all.  Missingness must be assessed on the raw
extract `data/cohort_v2_raw.csv`, i.e. the N = 1,865 patients of the analytic
cohort before the complete-case restriction.
"""
import os

import pandas as pd

from apar_common import (ALB_GDL_TO_GL, common_args, load_cohort, resolve_path)

# label -> spreadsheet column, in the order in which they appear in Table S1
VARIABLES = [
    ('Age', 'age'),
    ('Sex', 'gender_recode'),
    ('Body mass index', 'bmi'),
    ('SOFA score', 'sofa'),
    ('MELD score', 'meld_plain'),
    ('MELD-Na score', 'meld_na'),
    ('APS III', 'apsiii'),
    ('SAPS II', 'sapsii'),
    ('OASIS', 'oasis'),
    ('Hemoglobin', 'first_hemoglobin'),
    ('Platelet count', 'first_platelet_count'),
    ('Red blood cell count', 'first_red_blood_cells'),
    ('White blood cell count', 'first_white_blood_cells'),
    ('Absolute neutrophil count', 'first_absolute_neutrophil_count'),
    ('Hemoglobin A1c', 'first_hemoglobin_a1c'),
    ('Albumin', 'first_albumin'),
    ('Alkaline phosphatase', 'ALP'),
    ('Sodium', 'first_sodium'),
    ('Lactate', 'first_lactate'),
    ('Partial pressure of carbon dioxide', 'first_pco2'),
    ('pH', 'first_ph'),
    ('Partial pressure of oxygen', 'first_po2'),
    ('Prothrombin time', 'first_pt'),
    ('International normalised ratio', 'first_inr'),
    ('Total cholesterol', 'first_cholesterol_total'),
    ('Triglycerides', 'first_triglycerides'),
    ('Alanine aminotransferase', 'first_alanine_aminotransferase_alt'),
    ('Aspartate aminotransferase', 'first_asparate_aminotransferase_ast'),
    ('Total bilirubin', 'first_bilirubin_total'),
    ('Creatinine', 'first_creatinine'),
    ('NT-proBNP', 'first_ntprobnp'),
    ('Acute kidney injury', 'aki'),
    ('ACLF', 'aclf_binary'),
    ('Cirrhosis aetiology', 'aetiology'),
    ('APAR (exposure)', 'apar'),
]

MISSING_THRESHOLD = 15.0

# Severity scores and diagnostic flags are computed in apar_common.load_cohort()
# and are absent from the raw extract, so they are merged in from the cohort
# frame before missingness is counted.
COHORT_ONLY = ['meld_plain', 'meld_na', 'aki', 'aclf_binary', 'aetiology']


def raw_cohort(raw_path, stay_ids, cohort=None, bmi_path=None):
    """The pre-imputation extract, restricted to the patients of the analytic
    cohort (N = 1,865)."""
    raw = (pd.read_csv(raw_path) if str(raw_path).lower().endswith('.csv')
           else pd.read_excel(raw_path))
    out = raw[raw['stay_id'].isin(set(stay_ids))].copy()
    # Height and weight are not part of the laboratory extract, so BMI is built
    # separately by sql/05_bmi_extraction.sql (first ICU day, from the MIMIC-IV
    # derived tables) and merged in here.  If that file is unavailable the
    # column is absent and the variable is simply skipped, as before.
    if bmi_path and os.path.exists(bmi_path):
        bmi = pd.read_csv(bmi_path)
        out = out.drop(columns=[c for c in ('bmi',) if c in out.columns])
        out = out.merge(bmi[['stay_id', 'bmi']], on='stay_id', how='left')
    # 'ALP/ALB' is ALP (IU/L) / albumin (g/dL) as written by the extraction;
    # the reported APAR divides by albumin in g/L, hence the factor of 10.
    out['apar'] = out['ALP/ALB'] / ALB_GDL_TO_GL
    if cohort is not None:
        add = [c for c in COHORT_ONLY if c in cohort.columns]
        out = out.drop(columns=[c for c in add if c in out.columns])
        out = out.merge(cohort[['stay_id'] + add], on='stay_id', how='left')
    return out


def main():
    parser = common_args(__doc__)
    parser.add_argument('--raw',
                        default=resolve_path('cohort_v2_raw.csv', 'APAR_RAW'),
                        help='raw extract of the analytic cohort (one row per stay_id)')
    parser.add_argument('--bmi',
                        default=resolve_path('bmi.csv', 'APAR_BMI'),
                        help='BMI per stay_id, built by sql/05_bmi_extraction.sql')
    args = parser.parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    m, sc = load_cohort(args.cohort, args.derived)     # patient list + scores
    raw = raw_cohort(args.raw, m['stay_id'], m, args.bmi)
    N = len(raw)
    print(f'pre-imputation cohort: N = {N}')

    ALIAS = {'gender_recode': 'gender'}      # the raw extract codes sex as M/F

    rows, absent = [], []
    for label, col in VARIABLES:
        col = col if col in raw.columns else ALIAS.get(col, col)
        if col not in raw.columns:
            absent.append(col)
            continue
        n_obs = int(raw[col].notna().sum())
        n_miss = N - n_obs
        pct = n_miss / N * 100
        rows.append(dict(Variable=label, Observed=n_obs, Missing=n_miss,
                         Missing_pct=round(pct, 1),
                         Excluded='Yes' if pct > MISSING_THRESHOLD else 'No'))
    if absent:
        print('  columns absent from the raw extract (skipped):', absent)

    tab = pd.DataFrame(rows)
    tab.to_csv(f'{args.outdir}/TableS1_missingness.csv', index=False, encoding='utf-8-sig')

    excluded = tab.loc[tab.Excluded == 'Yes', 'Variable'].tolist()
    print(tab.to_string(index=False))
    print(f'\nExcluded (> {MISSING_THRESHOLD}% missing, {len(excluded)} variables): '
          f'{", ".join(excluded)}')
    print('Outputs written to', args.outdir)


if __name__ == '__main__':
    main()
