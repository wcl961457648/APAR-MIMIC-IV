"""
Tables 2 and 3 of the manuscript:

  Table 2 - APAR as a continuous exposure: HR per 1 unit and per 1 SD for the
            four adjustment models, at 30 and 90 days.  The SD is read from the
            data (apar_common.load_cohort key 'SD_apar'; 4.71 units in this
            cohort) and is never hard-coded: HR_perSD = exp(SD * beta).
            NB: an earlier N = 2,209 version of this cohort recorded albumin in
            g/dL and had SD = 28.05.  That figure is obsolete and must not be
            reintroduced.

  Table 3 - APAR by quartiles (Q1 reference): HRs, P for linear trend.

Also writes the event count per quartile (used in Figure 3 and its legend),
the same counts for the complete-case sample in which Models 2-4 are fitted
(Table3_quartile_counts_complete_cases.csv), and the E-value for the primary
model (Model 3, Q4 vs Q1).

Usage:  python 01_main_models.py [--cohort ...] [--derived ...] [--outdir ...]
"""
import warnings

warnings.filterwarnings('ignore')

import os

import numpy as np
import pandas as pd
from lifelines import CoxPHFitter

from apar_common import (ADJ, E30, E90, HORIZONS, MODELS, T30, T90, common_args,
                         e_value, load_cohort, survival_frame)

PENALIZER = 1e-6  # tiny ridge term only for numerical stability


def fit_cox(m, cols, T, E, penalizer=PENALIZER):
    d = survival_frame(m, cols, T, E)
    cph = CoxPHFitter(penalizer=penalizer)
    cph.fit(d, duration_col='T', event_col='E', show_progress=False)
    return cph, d


def main():
    args = common_args(__doc__).parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    m, sc = load_cohort(args.cohort, args.derived)
    SD_TRUE = sc['SD_apar']
    print(f"N = {sc['N']} | SD(APAR) = {SD_TRUE:.3f} | "
          f"quartile cuts = {sc['quartiles'][0]:.2f}/{sc['quartiles'][1]:.2f}/{sc['quartiles'][2]:.2f}")
    print(f"events: 30-day {sc['events_30d']}, 90-day {sc['events_90d']}")

    # ---------------------------------------------------------- Table 2
    rows = []
    for mname, cols in MODELS.items():
        for hz, T, E, _ in HORIZONS:
            cph, d = fit_cox(m, cols, T, E)
            b = cph.params_['apar']
            se = cph.standard_errors_['apar']
            p = cph.summary.loc['apar', 'p']
            rows.append(dict(
                Model=mname, Horizon=hz, N=len(d), Events=int(d['E'].sum()),
                C_index=cph.concordance_index_,
                HR_per1=np.exp(b), lo1=np.exp(b - 1.96 * se), hi1=np.exp(b + 1.96 * se), P1=p,
                HR_perSD=np.exp(SD_TRUE * b), loS=np.exp(SD_TRUE * (b - 1.96 * se)),
                hiS=np.exp(SD_TRUE * (b + 1.96 * se)), PSD=p))
    tab2 = pd.DataFrame(rows)
    tab2.to_csv(f'{args.outdir}/Table2_continuous_APAR.csv', index=False, encoding='utf-8-sig')

    # ---------------------------------------------------------- Table 3
    rows = []
    for mname, cols in MODELS.items():
        base = [c for c in cols if c != 'apar']
        dums = pd.get_dummies(m['apar_q'], prefix='aq', drop_first=True).astype(float)
        dd_all = pd.concat([m[base], dums], axis=1)
        for hz, T, E, _ in HORIZONS:
            dd = dd_all.copy()
            dd['T'] = m[T]
            dd['E'] = m[E]
            dd = dd.dropna().rename(columns={T: 'T', E: 'E'})
            cph = CoxPHFitter(penalizer=PENALIZER)
            cph.fit(dd, duration_col='T', event_col='E', show_progress=False)
            row = dict(Model=mname, Horizon=hz, N=len(dd), Events=int(dd['E'].sum()),
                       C_index=cph.concordance_index_)
            for q in ['aq_Q2', 'aq_Q3', 'aq_Q4']:
                s = cph.summary.loc[q]
                row[f'{q[-2:]}_HR'] = np.exp(s['coef'])
                row[f'{q[-2:]}_lo'] = np.exp(s['coef lower 95%'])
                row[f'{q[-2:]}_hi'] = np.exp(s['coef upper 95%'])
                row[f'{q[-2:]}_P'] = s['p']
            # P for trend: quartile entered as a single ordinal term
            dtr = survival_frame(m, base + ['apar_q_ord'], T, E)
            ctr = CoxPHFitter(penalizer=PENALIZER)
            ctr.fit(dtr, duration_col='T', event_col='E', show_progress=False)
            row['P_trend'] = ctr.summary.loc['apar_q_ord', 'p']
            rows.append(row)
    tab3 = pd.DataFrame(rows)
    tab3.to_csv(f'{args.outdir}/Table3_quartiles_APAR.csv', index=False, encoding='utf-8-sig')

    # ------------------------------------------- mortality by quartile
    mort = []
    for hz, T, E, _ in HORIZONS:
        g = m.groupby('apar_q', observed=True).agg(n=('apar', 'size'), events=(E, 'sum'))
        g['rate'] = (g['events'] / g['n'] * 100).round(1)
        for q, r in g.iterrows():
            mort.append(dict(Horizon=hz, Quartile=q, n=int(r['n']),
                             deaths=int(r['events']), rate=r['rate']))
    mort = pd.DataFrame(mort)
    mort.to_csv(f'{args.outdir}/mortality_by_quartile.csv', index=False, encoding='utf-8-sig')


    # --------------------------------- complete-case counts per quartile
    # Table 3 reports the whole-cohort counts (N = 1,865) next to hazard
    # ratios that, for Models 2-4, are estimated in the complete-case sample
    # (n = 1,831, 590 deaths at 30 days and 744 at 90 days).  Model 1 is
    # unadjusted, so it stays on the whole cohort.  Writing these per-quartile
    # counts lets a reader reconcile both sets of numbers in the table.
    base_cc = [c for c in MODELS['M3'] if c != 'apar']
    cc = []
    for hz, T, E, _ in HORIZONS:
        keep = survival_frame(m, base_cc, T, E).index
        sub = m.loc[keep]
        g = sub.groupby('apar_q', observed=True).agg(n=('apar', 'size'),
                                                     deaths=(E, 'sum'))
        for q, r in g.iterrows():
            cc.append(dict(Horizon=hz, Quartile=q, n=int(r['n']),
                           deaths=int(r['deaths']),
                           rate=round(r['deaths'] / r['n'] * 100, 1)))
    cc = pd.DataFrame(cc)
    cc.to_csv(f'{args.outdir}/Table3_quartile_counts_complete_cases.csv',
              index=False, encoding='utf-8-sig')

    # ---------------------------------------------------------- E-value
    ev = []
    for hz in ['30d', '90d']:
        r = tab3[(tab3.Model == 'M3') & (tab3.Horizon == hz)].iloc[0]
        pt, ci = e_value(r['Q4_HR']), e_value(r['Q4_lo'])
        ev.append(dict(Horizon=hz, HR_Q4=r['Q4_HR'], CI_lo=r['Q4_lo'],
                       E_point=pt, E_CI=ci))
    pd.DataFrame(ev).to_csv(f'{args.outdir}/e_value.csv', index=False, encoding='utf-8-sig')

    pd.set_option('display.width', 200)
    print('\n===== Table 2 (continuous, Model 3) =====')
    print(tab2[tab2.Model == 'M3'][['Horizon', 'N', 'Events', 'C_index',
                                    'HR_per1', 'lo1', 'hi1', 'HR_perSD', 'loS', 'hiS']]
          .to_string(index=False))
    print('\n===== Table 3 (quartiles, Model 3) =====')
    print(tab3[tab3.Model == 'M3'][['Horizon', 'Q2_HR', 'Q3_HR', 'Q4_HR', 'P_trend']]
          .to_string(index=False))
    print('\n===== Mortality by quartile =====')
    print(mort.to_string(index=False))
    print('\n===== E-value =====')
    print(pd.DataFrame(ev).to_string(index=False))
    print('\nOutputs written to', args.outdir)


if __name__ == '__main__':
    main()
